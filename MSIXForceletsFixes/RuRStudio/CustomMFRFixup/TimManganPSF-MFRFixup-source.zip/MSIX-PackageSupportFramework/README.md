# A NOTE ABOUT THIS FORK
This is the TimMangan fork of the Microsoft MSIX-PackageSupportFramework project.

While Microsoft created the initial open-source project for the Package Support Framework, they have neglected it for some time and seem disinterested in maintaining it, so this fork represents the lastest active branch.
    ![PsfLogo](https://user-images.githubusercontent.com/19534997/151001486-af6b65de-9046-4b23-9112-4916a844e81c.png)
=======



# Package Support Framework
This project provides tools, libraries, documentation and samples for creating runtime fixes (also called *fixups*) for compatibility issues that enable Windows desktop applications to be distributed and executed as MSIX packaged apps.  This fork is directly used by the PsfTooling and TMEditX applications.  Additionally, several other tool vendors are believed to look to this source as the basis their own private repositories.

The original fork for this project is a Microsoft project, and this project remains forked from the original, although this fork is now considered the up-to-date and managed source for the PSF and there is no longer any intent to create pull requests back into the Microsoft fork. 

Here are some common examples where you can find the Package Support Framework (PSF) useful:

* Your app can't find some DLLs when launched. You may need to set your current working directory. You can learn about the required current working directory in the original shortcut before you converted to MSIX.
* The app writes to the install folder. This issue typically shows up as ACCESS DENIED errors in [Process Monitor](https://docs.microsoft.com/sysinternals/downloads/procmon) as demonstrated in the following image.
    ![ProcMon Logfile](procmon_logfile.png)
* Your app needs to pass arguments to the executable when launched. You can easily configure arguments by using [PSF Launcher](https://github.com/microsoft/MSIX-PackageSupportFramework/tree/master/PsfLauncher).

You can learn more about how to identify compatibility issues [here](https://docs.microsoft.com/windows/msix/psf/package-support-framework#identify-packaged-application-compatibility-issues). If you have feedback, please create [an issue](https://github.com/Microsoft/MSIX-PackageSupportFramework/issues) or post a message in our [tech community](https://techcommunity.microsoft.com/t5/Package-Support-Framework/bd-p/Package-Support).

## Version 
Although the original versions of the Microsoft fork, or earlier versions of this fork did not mark any version information on the output binaries, we now version the PsfLauncher.exe file with a release date based scheme.


## Documentation
See these articles for core documentation about using the Package Support Framework:

* [Apply runtime fixes by using the Package Support Framework](https://docs.microsoft.com/windows/uwp/porting/package-support-framework): This article provides step-by-step instructions for the main Package Support Framework workflows.
* [Run scripts with the Package Support Framework](https://docs.microsoft.com/windows/msix/psf/run-scripts-with-package-support-framework): This article demonstrates how to run scripts to customize an application dynamically to the user's environment after it is packaged using MSIX.

The following additional resources provide additional information about specific scenarios:
* [Package Support Framework package layout](layout.md)
* [Package Support Framework NuGet package install](https://www.nuget.org/packages/Microsoft.PackageSupportFramework)
* [Instructions for authoring your own fixup DLL](Authoring.md)

## Developer Note:
If you wish to build the PSF from source, you will need to install the Windows Driver Kit (WDK) in order to build the MfrFixup.

## Get the pre-built Package Support Framework binaries
Look for a versioned folder in the Develop branch code starting with "ZipRelease-v" that will contain pre-built release and debug builds of the PSF in a zip format.  We are unable to use the GitHub "release" mechanism without breaking your ability to compare sources here to the original Microsoft sources.

The older Microsoft builds for the Package Support Framework binaries from [Nuget.org](https://www.nuget.org/packages/Microsoft.PackageSupportFramework). To extract the binaries, rename the package extension to .zip, unzip the file, and locate the binaries in the /bin folder. In a future release we are planning to make it easier to locate the binaries directly on GitHub.

## Branch structure
The original Microsoft Package Support Framework adopted a **develop** and **master** branching style.
In this TimMangan fork, the develop **develop** branch acts like the master and other branches are childs of develop.

### Master
The **master** branch represents the Microsoft Master source in the most recent NuGet package. The code in this branch is old. Do not use.

### Develop
The **develop** branch has the latest Release code. Make a private fork off the **develop** branch to make your own contributions to Package Support Framework.

## Fixup metadata
Each fixup and the PSF Launcher has a metadata file in XML format, which is used for some of the automated testing. Each file contains the following:

* `Version`: The version of the Package Support Framework is in MAJOR.MINOR.PATCH format according to [Sem Version 2](https://semver.org/).
* `MinimumWindowsPlatform`: The minimum windows version required for the fixup or PSF Launcher.
* `Description`: A short description of the fixup.
* `WhenToUse`: Heuristics on when you should apply the fixup.

The metadata file schema is provided [here](MetadataSchema.xsd).

## Data/Telemetry
The Package Support Framework includes telemetry that collects usage data and sends it to Microsoft to help improve their products and services. Read Microsoft's [privacy statement to learn more](https://privacy.microsoft.com/en-US/privacystatement). However, data will be collected only when both of the following conditions are met:

* The Package Support Framework binaries are used from the [NuGet package](https://www.nuget.org/packages/Microsoft.PackageSupportFramework) on a Windows 10 computer.
* The user has enabled collection of data on the computer.

The NuGet package contains signed binaries and will collect usage data from the computer. Telemetry is not collected when the binaries are built locally by cloning the repo or downloading the binaries directly.  This means that while telemetry code is present in the binaries in the ZipRelease folder, it isn't active if you include those binaries in your MSIX packages.

## License
The Package Support Framework code is licensed under the [MIT License](https://github.com/Microsoft/MSIX-PackageSupportFramework/blob/master/LICENSE).

## Contribute
This project welcomes contributions and suggestions. Contributions to the Microsoft branch require you to agree to a Contributor License Agreement (CLA) declaring that you have the right to, and actually do, grant us the rights to use your contribution. For details, visit https://cla.microsoft.com.  

For contributing to the TimMangan fork, contact Tim as tmangan@tmurgent.com 

Submit your own fixup(s) to the community:
1. Create a private fork for yourself
2. Make your changes in your private branch
3. For new files that you are adding include the following Copyright statement.\
//-------------------------------------------------------------------------------------------------------\
// Copyright (c) #YOUR NAME#. All rights reserved.\
// Licensed under the MIT license. See LICENSE file in the project root for full license information.\
//-------------------------------------------------------------------------------------------------------
4. Create a pull request into 'fork:Microsoft/MSIX-PackageSupportFramework' 'base:develop'

When you submit a pull request, a CLA-bot will automatically determine whether you need to provide a CLA and decorate the PR appropriately (e.g., label, comment). Simply follow the instructions provided by the bot. You will only need to do this once across all repos using our CLA.

Here is how you can contribute to the Package Support Framework:

* [Submit bugs](https://github.com/Microsoft/MSIX-PackageSupportFramework/issues) and help us verify fixes.
* [Submit pull requests](https://github.com/Microsoft/MSIX-PackageSupportFramework/pulls) for bug fixes and features and discuss existing proposals.

This project has adopted the [Microsoft Open Source Code of Conduct](https://opensource.microsoft.com/codeofconduct/). For more information see the [Code of Conduct FAQ](https://opensource.microsoft.com/codeofconduct/faq/) or contact [opencode@microsoft.com](mailto:opencode@microsoft.com) with any additional questions or comments.

### Testing your changes.
Before making a pull request please run the regression tests to make sure your changes did not break existing behavior. 

Please head to the tests solution and follow the instructions inside readme.md for details on how to run these automated tests.

## Fixup Metadata
Each fixup and the PSF Launcher has a metadata file in xml format.  Each file contains the following  
 1. Version:  The version of the PSF is in MAJOR.MINOR.PATCH format according to [Sem Version 2](https://semver.org/)
 2. Minimum Windows Platform the the minimum windows version required for the fixup or PSF Launcher.
 3. Description: Short description of the fixup.
 4. WhenToUse: Heuristics on when you should apply the fixup.

Additionally, we have the XSD for the metadata files located in the solutions folder.

## Scripts
Scripting support is allowed on RS2 and higher builds of windows.  If PSf is executed on RS1, scripts will not execute even if they are specified in the configuration file.

## XML configuration files.
PSF allows you to write the configuration file in either json or xml.  Configuration files written in xml need to be translated to json before psf can use them. 

Because PSF uses json files for the configuration you will need to convert the xml configuration file to json.

To convert an xml configuration to json please use msxsl.exe located in the xmlToJsonConverter folder to convert your xml configuration to json.  Here is an example command.

`msxsl.exe [location of your xml file] -format.xsl -o config.json`

## Data/Telemetry
While the source code retains telemetry interfaces to collect and send telemetry to Microsoft (if enabled), this build of the source disables all telemetry. 

## NUGET PACKAGE
The purpose of this NuGet package is to provide the resources of the PSF that can be copied by an application that wishes to produce an MSIX package.

The Nuget package has signed binaries, organized under the content folder.  The release version of the PSF is under the psf subfolder, and the debug version of the PSF is under the psfd subfolder.

Under each subfolder are both the 32 and 64 bit versions of the PSF components that have bit-specific names, such as "PslLauncher32.exe" and "PsfLauncher64.exe".  Some of the dependencies of the PSF are bit-specific but the names of the files are the same, so these will be found in subfolders of the psf/psfd names "win32" or "amd64". 

See the PSF documentation wiki at https://github.com/TimMangan/MSIX-PackageSupportFramework/wiki for information on the components and especially dependencies that might be needed.