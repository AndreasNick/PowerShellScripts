//-------------------------------------------------------------------------------------------------------
// Copyright (C) Microsoft Corporation. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.
//-------------------------------------------------------------------------------------------------------

#include <algorithm>
#include <sstream>

#include <detour_transaction.h>
#include <psf_framework.h>
#include <psf_runtime.h>
#include <psf_logging.h>

#include "Config.h"
using namespace std::literals;

extern const wchar_t* g_PsfRunTimeName;

#if _DEBUG
#define MOREDEBUG 1
#endif 

struct loaded_fixup
{
    HMODULE module_handle = nullptr;
    PSFUninitializeProc uninitialize = nullptr;

    loaded_fixup() = default;
    loaded_fixup(const loaded_fixup&) = delete;
    loaded_fixup& operator=(const loaded_fixup&) = delete;

    loaded_fixup(loaded_fixup&& other) noexcept
    {
        swap(other);
    }

    loaded_fixup& operator=(loaded_fixup&& other) noexcept
    {
        swap(other);
    }

    ~loaded_fixup()
    {
        if (module_handle)
        {
            [[maybe_unused]] auto result = ::FreeLibrary(module_handle);
            assert(result);
        }
    }

    void swap(loaded_fixup& other)
    {
        std::swap(module_handle, other.module_handle);
        std::swap(uninitialize, other.uninitialize);
    }
};
std::vector<loaded_fixup> loaded_fixups;

bool usingPsf = false;
wchar_t g_PsfRunTimeModulePath[MAX_PATH];

void load_fixups()
{
    using namespace std::literals;

    if (auto config = PSFQueryCurrentExeConfig())
    {
        if (config != nullptr)
        {
            if (auto fixups = config->try_get("fixups"))
            {
                if (fixups != nullptr)
                {
                    for (auto& fixupConfig : fixups->as_array())
                    {
                        auto& fixup = loaded_fixups.emplace_back();

                        auto path = PackageRootPath() / fixupConfig.as_object().get("dll").as_string().wide();
                        Log(LogLevel_DebugBasic, "[%s%d]\tfixup to attempt to load as specified: %ls.", g_PsfRunTimeName, 0, path.c_str());
                        fixup.module_handle = ::LoadLibraryW(path.c_str());
                        if (!fixup.module_handle)
                        {
                            path.replace_extension();
                            path.concat((sizeof(void*) == 4) ? L"32.dll" : L"64.dll");
                            Log(LogLevel_DebugBasic, "[%s%d]\tfixup to attempt to load as: %ls.", g_PsfRunTimeName, 0, path.c_str());
                            fixup.module_handle = ::LoadLibraryW(path.c_str());

                            if (!fixup.module_handle)
                            {
                                Log(LogLevel_DebugBasic, "[%s%d]\tfixup not found as specified,checkroot of package.", g_PsfRunTimeName, 0);
                                std::filesystem::path pathfromroot = PackageRootPath() / path.filename().c_str();
                                fixup.module_handle = ::LoadLibraryW(pathfromroot.c_str());
                                if (fixup.module_handle)
                                {
                                    Log(LogLevel_DebugBasic, "[%s%d]\tfixup found at . %ls", g_PsfRunTimeName, 0, pathfromroot.c_str());
                                    path = pathfromroot;
                                }
                                else
                                {
                                    DWORD rember = GetLastError();
                                    DWORD att = ::GetFileAttributesW(pathfromroot.c_str());
                                    if (att != INVALID_FILE_ATTRIBUTES)
                                    {
                                        Log(LogLevel_Exception, "[%s%d]\t???file %ls attrib 0x%x but load error 0x%x", g_PsfRunTimeName,0, pathfromroot.c_str(), att, rember);
                                    }
                                }
                            }

                            if (!fixup.module_handle)
                            {
                                Log(LogLevel_DebugBasic, "[%s%d]\tfixup not found at root of package, look elsewhere.", g_PsfRunTimeName,0);
                                // just try to find it elsewhere as it isn't at the root
                                for (auto& dentry : std::filesystem::recursive_directory_iterator(PackageRootPath()))
                                {
                                    if (!fixup.module_handle)
                                    {
                                        try
                                        {
                                            if (dentry.path().filename().compare(path.filename().c_str()) == 0)
                                            {
                                                Log(LogLevel_DebugBasic, "[%s%d]\tfixup might be found as %ls.", g_PsfRunTimeName, 0, dentry.path().c_str());
                                                fixup.module_handle = ::LoadLibraryW(dentry.path().c_str());
                                                if (!fixup.module_handle)
                                                {
                                                    auto d2 = dentry.path();
                                                    d2.replace_extension();
                                                    d2.concat((sizeof(void*) == 4) ? L"32.dll" : L"64.dll");
                                                    fixup.module_handle = ::LoadLibraryW(d2.c_str());
                                                }
                                                if (fixup.module_handle)
                                                {
                                                    Log(LogLevel_DebugBasic, "[%s%d]\tfixup found at . %ls", g_PsfRunTimeName, 0, dentry.path().c_str());
                                                    path = dentry.path();
                                                    break;
                                                }
                                            }
                                        }
                                        catch (...)
                                        {
                                            Log(LogLevel_Exception, "[%s%d] Non-fatal error enumerating directories while looking for fixup.", g_PsfRunTimeName, 0);
                                        }
                                    }
                                    else
                                        break;
                                }
                            }


                            if (!fixup.module_handle)
                            {
                                if (GetLastError() == ERROR_NO_MORE_FILES)
                                {
                                    Log(LogLevel_Launching, "[%s%d]\tERROR: fixup not found in package; ignoring.", g_PsfRunTimeName, 0);
                                }
                                else
                                {
                                    auto message = narrow(path.c_str());
                                    throw_last_error(message.c_str());
                                }
                            }
                        }
                        if (fixup.module_handle)
                        {
                            Log(LogLevel_Launching, "[%s%d]\tInjected into current process: %ls\n", g_PsfRunTimeName, 0, path.c_str());

                            auto initialize = reinterpret_cast<PSFInitializeProc>(::GetProcAddress(fixup.module_handle, "PSFInitialize"));
                            if (!initialize)
                            {
                                auto message = "PSFInitialize export not found in "s + narrow(path.c_str());
                                throw_win32(ERROR_PROC_NOT_FOUND, message.c_str());
                            }
                            auto uninitialize = reinterpret_cast<PSFUninitializeProc>(::GetProcAddress(fixup.module_handle, "PSFUninitialize"));
                            if (!uninitialize)
                            {
                                auto message = "PSFUninitialize export not found in "s + narrow(path.c_str());
                                throw_win32(ERROR_PROC_NOT_FOUND, message.c_str());
                            }

                            auto transaction = detours::transaction();
                            check_win32(::DetourUpdateThread(::GetCurrentThread()));

                            // Only set the uninitialize pointer if the transaction commits successfully since that's our cue to clean
                            // it up, which will attempt to call DetourDetach
                            check_win32(initialize());
                            transaction.commit();
                            fixup.uninitialize = uninitialize;
                        }
                    }
                }
            }
        }
    }
}

void unload_fixups()
{
    while (!loaded_fixups.empty())
    {
        auto transaction = detours::transaction();
        check_win32(::DetourUpdateThread(::GetCurrentThread()));

        if (loaded_fixups.back().uninitialize)
        {
            [[maybe_unused]] auto result = loaded_fixups.back().uninitialize();
            assert(result == ERROR_SUCCESS);
        }

        transaction.commit();
        loaded_fixups.pop_back();
    }
}

using EntryPoint_t = int(__stdcall*)();
EntryPoint_t ApplicationEntryPoint = nullptr;
static int __stdcall FixupEntryPoint() noexcept try
{
    Log(LogLevel_DebugMaximum, "[%s%d] PsfRuntime FixupEntryPoint in App Pid=%d Tid=%d", g_PsfRunTimeName, 0, GetCurrentProcessId(), GetCurrentThreadId());
    load_fixups();

    // Try to open this nonexistent (we hope) key to make a marker in ProcessMonitor Traces
    HKEY dummy;
    std::wstring mark = L"PSF_READY_MARKER_" + psf::current_executable_path().filename().wstring();
    LSTATUS res = RegOpenKey(HKEY_CURRENT_USER, mark.c_str(), &dummy);
    if (res == ERROR_SUCCESS)
    {
        RegCloseKey(dummy);
    }
    Log(LogLevel_Launching, "[%s%d] PsfRuntime has completed adding all fixups and PSF_READY_MARKER is set.", g_PsfRunTimeName, 0);
    return ApplicationEntryPoint();
}
catch (...)
{
    int err = win32_from_caught_exception();
    Log(LogLevel_Exception, "[%s%d] Exception in PsfRuntime FixupEntryPoint() = 0x%x", g_PsfRunTimeName, 0, err);
    return  err;
}

void attach()
{
    try
    {
        Log(LogLevel_DebugIntermediate, "[%s%d] PsfRuntime Attach Pid=%d Tid=%d",  g_PsfRunTimeName, 0, GetCurrentProcessId(), GetCurrentThreadId());
        usingPsf = LoadConfig();
        Log(LogLevel_DebugIntermediate, "[%s%d] PsfRuntime loading of psf config complete - result=0x%x", g_PsfRunTimeName, 0, usingPsf);
        if (usingPsf)
        {
            // Restore the contents of the in memory import table that DetourCreateProcessWithDll* modified
            ::DetourRestoreAfterWith();

            auto transaction = detours::transaction();
            check_win32(::DetourUpdateThread(::GetCurrentThread()));

            Log(LogLevel_DebugIntermediate, "[%s%d] PsfRuntime start attaching fixup dlls.", g_PsfRunTimeName, 0);
    
            // Call DetourAttach for all APIs that PsfRuntime detours
            int countIntercepts = psf::attach_count_all();
            Log(LogLevel_DebugIntermediate, "[%s%d] PsfRuntime fixup dlls %d were attached.", g_PsfRunTimeName, 0, countIntercepts);

            // We can't call LoadLibrary in DllMain, so hook the application's entry point and do initialization then
            ApplicationEntryPoint = reinterpret_cast<EntryPoint_t>(::DetourGetEntryPoint(nullptr));
            if (!ApplicationEntryPoint)
            {
                throw_last_error();
            }
            check_win32(::DetourAttach(reinterpret_cast<void**>(&ApplicationEntryPoint), FixupEntryPoint));

            transaction.commit();
            Log(LogLevel_Launching, "[%s%d] PsfRuntime is loaded and configured.", g_PsfRunTimeName, 0);
        }
    }
    catch (...)
    {
        Log(LogLevel_Exception, "[%s%d] App is not running inside the container, but will be allowed to run.", g_PsfRunTimeName, 0);
    }
}

void detach()
{
    try
    {
        if (usingPsf)
        {
            //Log(LogLevel_DebugMaximum,"[%s%d] DEBUG: PsfRuntime Dettach Pid=%d", g_PsfRunTimeName, 0, GetCurrentProcessId());
            // Unload in the reverse order as we initialized
            unload_fixups();

            auto transaction = detours::transaction();
            check_win32(::DetourUpdateThread(::GetCurrentThread()));
            psf::detach_all();
            transaction.commit();
        }
    }
    catch (...)
    {
        Log(LogLevel_Exception, "[%s%d] App is not running inside the container, but will be allowed to exit without error.", g_PsfRunTimeName, 0);
    }
}

BOOL APIENTRY DllMain(HMODULE hModule, DWORD reason, LPVOID) noexcept try
{

#if BLOCKDEBUGOUTPUTTEST
    HANDLE Handle = OpenProcess(
        PROCESS_QUERY_INFORMATION | PROCESS_VM_READ,
        FALSE,
        GetCurrentProcessId() /* This is the PID, you can find one from windows task manager */
    );
    if (Handle)
    {
        WCHAR Buffer[MAX_PATH];
        if (::GetModuleFileNameEx(Handle, 0, Buffer, MAX_PATH))
        {
            std::wstring xxx = Buffer;
            if (xxx.find(L"rsession.exe") != std::wstring::npos)
            {
                g_psf_NoLogging = true;
                //printf("testing...");
                //psf::wait_for_debugger();
                // DEBUG_EVENT evt;
                // WaitForDebugEventEx(&evt, 0);
            }
        }
        else
        {
            // You better call GetLastError() here
        }
        CloseHandle(Handle);
    }
#endif

    Log(LogLevel_DebugMaximum, "[%s%d] PsfRuntime: In DllMain Pid=%d Tid=%d reason=0x%x", g_PsfRunTimeName, 0, GetCurrentProcessId(), GetCurrentThreadId(), reason);
    // Per detours documentation, immediately return true if running in a helper process
    if (::DetourIsHelperProcess())
    {
        Log(LogLevel_Launching, "[%s%d] PsfRuntime: Is Helper Process", g_PsfRunTimeName, 0);
        return TRUE;
    }

    switch (reason)
    {
    case DLL_PROCESS_ATTACH:
        try
        {
            // Record the location for ourselves in case we need to inject it into another new process (CreateProcessHook.cpp).
            if (::GetModuleFileName(hModule, g_PsfRunTimeModulePath, MAX_PATH) == 0)
            {
                g_PsfRunTimeModulePath[0] = 0x0;
            }


            attach();
        }
        catch (...)
        {
            Log(LogLevel_Exception, "[%s%d] PsfRuntime: Exception attaching", g_PsfRunTimeName, 0);
            unload_fixups();
            throw;
        }
        break;

    case DLL_PROCESS_DETACH:
        detach();
        break;
    case DLL_THREAD_ATTACH:
        //Log(LogLevel_DebugMaximum, "[%s%d] PsfRuntime: Reason Thread Attach Tid=0x%x", g_PsfRunTimeName, 0, GetCurrentThreadId());
        break;
    case DLL_THREAD_DETACH:
        //Log(LogLevel_DebugMaximum, "[%s%d] PsfRuntime: Reason Thread Detach  Tid=0x%x", g_PsfRunTimeName, 0, GetCurrentThreadId()); 
        break;
    default:
        Log(LogLevel_DebugIntermediate, "[%s%d] PsfRuntime: DllMain Reason %d", g_PsfRunTimeName, 0, reason);
        break;
    }

    return TRUE;
}
catch (...)
{
    Log(LogLevel_Exception, "[%s%d] PsfRuntime: Exception in dllMain", g_PsfRunTimeName, 0);
    ::PSFReportError(widen(message_from_caught_exception()).c_str());
    ::SetLastError(win32_from_caught_exception());
    return false;
}
