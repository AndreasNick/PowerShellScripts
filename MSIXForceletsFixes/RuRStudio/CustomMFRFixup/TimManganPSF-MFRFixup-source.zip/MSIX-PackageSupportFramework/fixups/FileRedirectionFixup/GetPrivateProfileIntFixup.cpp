//-------------------------------------------------------------------------------------------------------
// Copyright (C) Tim Mangan, TMurgent Technologies, LLP. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.
//-------------------------------------------------------------------------------------------------------

#include <errno.h>
#include "FunctionImplementations.h"
#include "PathRedirection.h"
#include <psf_logging.h>

template <typename CharT>
UINT __stdcall GetPrivateProfileIntFixup(
    _In_opt_ const CharT* sectionName,
    _In_opt_ const CharT* key,
    _In_opt_ const INT nDefault,
    _In_opt_ const CharT* fileName) noexcept
{
    auto guard = g_reentrancyGuard.enter();
    DWORD GetPrivateProfileIntInstance = ++g_FileIntceptInstance;
    try
    {
        if (guard)
        {
            if constexpr (psf::is_ansi<CharT>)
            {
                if (fileName != NULL)
                {
                    LogString(LogLevel_DebugBasic, g_FrfModuleName, GetPrivateProfileIntInstance,L"GetPrivateProfileIntFixup for fileName", widen_argument(fileName).c_str());
                }
                else
                {
                    Log(LogLevel_DebugBasic, L"[%s%d] GetPrivateProfileIntFixup for null file.", g_FrfModuleName, GetPrivateProfileIntInstance);
                }
                if (sectionName != NULL)
                {
                    LogString(LogLevel_DebugBasic, g_FrfModuleName, GetPrivateProfileIntInstance,L" Section", widen_argument(sectionName).c_str());
                }
                if (key != NULL)
                {
                    LogString(LogLevel_DebugBasic, g_FrfModuleName, GetPrivateProfileIntInstance,L" Key", widen_argument(key).c_str());
                }
            }
            else
            {
                if (fileName != NULL)
                {
                    LogString(LogLevel_DebugBasic, g_FrfModuleName, GetPrivateProfileIntInstance,L"GetPrivateProfileIntFixup for fileName", fileName);
                }
                else
                {
                    Log(LogLevel_DebugBasic, L"[%s%d] GetPrivateProfileIntFixup for null file.", g_FrfModuleName, GetPrivateProfileIntInstance);
                }
                if (sectionName != NULL)
                {
                    LogString(LogLevel_DebugBasic, g_FrfModuleName, GetPrivateProfileIntInstance,L" Section", sectionName);
                }
                if (key != NULL)
                {
                    LogString(LogLevel_DebugBasic, g_FrfModuleName, GetPrivateProfileIntInstance,L" Key", key);
                }
            }
            if (fileName != NULL)
            {
                if (!IsUnderUserAppDataLocalPackages(fileName))
                {
                    path_redirect_info  pri = ShouldRedirectV2(fileName, redirect_flags::copy_on_read, GetPrivateProfileIntInstance);
                    if (pri.should_redirect)
                    {
                        if constexpr (psf::is_ansi<CharT>)
                        {
                            UINT retval = impl::GetPrivateProfileIntW(widen_argument(sectionName).c_str(), widen_argument(key).c_str(), nDefault, pri.redirect_path.c_str());
                            Log(LogLevel_DebugBasic, L" [%s%d] Returned uint: %d ", g_FrfModuleName, GetPrivateProfileIntInstance, retval);
                            return retval;
                        }
                        else
                        {
                            UINT retval = impl::GetPrivateProfileIntW(sectionName, key, nDefault, pri.redirect_path.c_str());
                            Log(LogLevel_DebugBasic, L" [%s%d] Returned uint: %d ", g_FrfModuleName, GetPrivateProfileIntInstance, retval);
                            return retval;
                        }
                    }
                }
                else
                {
                    Log(LogLevel_DebugBasic, L"[%s%d]  Under LocalAppData\\Packages, don't redirect", g_FrfModuleName, GetPrivateProfileIntInstance);
                }
            }
            else
            {
                Log(LogLevel_DebugBasic, L"[%s%d]  null filename, don't redirect as may be registry based or default.", g_FrfModuleName, GetPrivateProfileIntInstance);
            }
        }
    }
    // Fall back to assuming no redirection is necessary if exception
    LOGGED_CATCHHANDLER_MIN(LogLevel_Exception, g_FrfModuleName, GetPrivateProfileIntInstance, L"GetPrivateProfileInt")


    UINT uVal = impl::GetPrivateProfileInt(sectionName, key, nDefault, fileName);
    Log(LogLevel_DebugBasic,  L"[%s%d] Returning 0x%x", g_FrfModuleName, GetPrivateProfileIntInstance,uVal);

    return uVal;

}
DECLARE_STRING_FIXUP(impl::GetPrivateProfileInt, GetPrivateProfileIntFixup);
