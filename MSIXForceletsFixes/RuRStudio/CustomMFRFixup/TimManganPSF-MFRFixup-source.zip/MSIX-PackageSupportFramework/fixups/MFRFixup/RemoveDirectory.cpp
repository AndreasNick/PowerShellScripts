//-------------------------------------------------------------------------------------------------------
// Copyright (C) Microsoft Corporation. All rights reserved.
// Copyright (C) TMurgent Technologies, LLP. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.
//-------------------------------------------------------------------------------------------------------

// Microsoft Documentation on this API:https://docs.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-removedirectorya


// NOTE:  MSIX packages as delivered can't have empty directories, so tools like the MMPT solve this by adding a dummy file into any empty package directory.
//        This does not apply to directories made by the runtime of the app after installation.
//        Currently, this code ignores this problem.  
//        But we could catch the error 0x91, look for the known MMPT dummy file name, remove that file, and retry. 


#include <errno.h>
#include "FunctionImplementations.h"
#include <psf_logging.h>

#include "ManagedPathTypes.h"
#include "PathUtilities.h"
#include "DetermineCohorts.h"
#include "DetermineIlvPaths.h"

#ifdef _M_IX86
#pragma comment(linker, "/EXPORT:RemoveFileFixupAnsi_Fixup=impl::_RemoveFileFixup.ansi")  // A test to see if exporting these names helps ProcessMonitor stack traces.
#pragma comment(linker, "/EXPORT:RemoveFileFixupWide_Fixup=impl::_RemoveFileFixup.wide")  // A test to see if exporting these names helps ProcessMonitor stack traces.
#pragma comment(linker, "/EXPORT:WRAPPER_REMOVEFILE=_WRAPPER_REMOVEFILE.wide")
#else
#pragma comment(linker, "/EXPORT:RemoveFileFixupAnsi_Fixup=impl::RemoveFileFixup.ansi")  // A test to see if exporting these names helps ProcessMonitor stack traces.
#pragma comment(linker, "/EXPORT:RemoveFileFixupWide_Fixup=impl::RemoveFileFixup.wide")  // A test to see if exporting these names helps ProcessMonitor stack traces.
#pragma comment(linker, "/EXPORT:WRAPPER_REMOVEFILE=WRAPPER_REMOVEFILE.wide")
#endif

BOOL  WRAPPER_REMOVEDIRECTORY(Json_Debug_Levels debugRequestLevel, std::wstring theRemovingDirectory, DWORD dllInstance)
{
    std::wstring LongRemovingDirectory = MakeLongPath(theRemovingDirectory);
    BOOL retfinal = impl::RemoveDirectoryW(LongRemovingDirectory.c_str());
    if (retfinal == 0)
    {
        Log(debugRequestLevel, L"[%s%d] RemoveDirectory returns result FAILURE 0x%x on file '%s'", g_MfrModuleName, dllInstance, GetLastError(), LongRemovingDirectory.c_str());
    }
    else
    {
        Log(debugRequestLevel, L"[%s%d] RemoveDirectory returns result SUCCESS 0x%x on file '%s'", g_MfrModuleName, dllInstance, retfinal, LongRemovingDirectory.c_str());
    }
    return retfinal;
}


template <typename CharT>
BOOL __stdcall RemoveDirectoryFixup(_In_ const CharT* pathName) noexcept
{
    DWORD dllInstance = ++g_InterceptInstance;

    auto guard = g_reentrancyGuard.enter();
    BOOL retfinal;
    try
    {
        if (guard)
        {
            std::wstring wPathName = widen(pathName);
            wPathName = AdjustSlashes(wPathName, dllInstance);
            LogString(LogLevel_DebugBasic, g_MfrModuleName, dllInstance, L"RemoveDirectoryFixup for pathName", wPathName.c_str());

            wPathName = AdjustBadUNC(wPathName, dllInstance, L"RemoveDirectoryFixup");

            Cohorts cohorts;
            DetermineCohorts(LogLevel_DebugIntermediate, wPathName, &cohorts, dllInstance, L"RemoveDirectoryFixup");

            if (!MFRConfiguration.Ilv_Aware)
            {
                // This get is inherently a write operation in all cases.
                // There is no need to COW, just create the redirected folder, but may need to create parent folders first.

                switch (cohorts.file_mfr.Request_MfrPathType)
                {
                case mfr::mfr_path_types::in_native_area:
                    if (cohorts.map.Valid_mapping == mfr::mfr_enabled_types::enabled &&
                        cohorts.map.RedirectionFlags == mfr::mfr_redirect_flags::prefer_redirection_local)
                    {
                        // try the request path, which must be the local redirected version by definition, and then a package equivalent
                        if (cohorts.map.IsAnExclusionToRedirect == mfr::mfr_exclusion_types::not_excluded && 
                            PathExists(cohorts.WsRedirected.c_str()))
                        {
                            // Still do this to set attributes
                            retfinal = WRAPPER_REMOVEDIRECTORY(LogLevel_DebugBasic, cohorts.WsRedirected, dllInstance);
#if IMPROVE_RETURN_ACCURACY
                            if (PathExists(cohortsWsPackage.c_str()))
                            {
                                retfinal = FALSE;
                                SetLastError(ERROR_ACCESS_DENIED);
                                Log(LogLevel_DebugBasic, "[%s%d] RemoveDirectoryFixup: Resetting return code to ERROR_ACCESS_DENIED.", g_MfrModuleName, dllInstance );
                            }
#endif
                            return retfinal;
                        }
                        else if (PathExists(cohorts.WsPackage.c_str()))
                        {
                            retfinal = FALSE;
                            SetLastError(ERROR_ACCESS_DENIED);
                            Log(LogLevel_DebugBasic, "[%s%d] RemoveDirectoryFixup: Setting return code to ERROR_ACCESS_DENIED.", g_MfrModuleName, dllInstance);
                            return retfinal;
                        }
                        else
                        {
                            // There isn't such a file anywhere. 
                            retfinal = FALSE;
                            SetLastError(ERROR_FILE_NOT_FOUND);  // not important if PATH or FILE not found.
                            Log(LogLevel_DebugBasic, "[%s%d] RemoveDirectoryFixup: Setting return code to ERROR_FILE_NOT_FOUND.", g_MfrModuleName, dllInstance);

                            return retfinal;
                        }
                    }
                    else if (cohorts.map.Valid_mapping == mfr::mfr_enabled_types::enabled &&
                        (cohorts.map.RedirectionFlags == mfr::mfr_redirect_flags::prefer_redirection_containerized ||
                            cohorts.map.RedirectionFlags == mfr::mfr_redirect_flags::prefer_redirection_if_package_vfs))
                    {
                        // try the redirected path, then package (via COW), then native (possibly via COW).
                        if (cohorts.map.IsAnExclusionToRedirect == mfr::mfr_exclusion_types::not_excluded && 
                            PathExists(cohorts.WsRedirected.c_str()))
                        {
                            retfinal = WRAPPER_REMOVEDIRECTORY(LogLevel_DebugBasic, cohorts.WsRedirected, dllInstance);
                            return retfinal;
                        }
                        else if (PathExists(cohorts.WsPackage.c_str()))
                        {
                            retfinal = FALSE;
                            SetLastError(ERROR_ACCESS_DENIED);
                            Log(LogLevel_DebugBasic, "[%s%d] RemoveDirectoryFixup: Setting return code to ERROR_ACCESS_DENIED.", g_MfrModuleName, dllInstance);
                            return retfinal;
                        }
                        else if (cohorts.NativeIsValidOptionInScenario &&
                            PathExists(cohorts.WsNative.c_str()))
                        {
                            retfinal = WRAPPER_REMOVEDIRECTORY(LogLevel_DebugBasic, cohorts.WsNative, dllInstance);
                            return retfinal;
                        }
                        else
                        {
                            // There isn't such a file anywhere.
                            return WRAPPER_REMOVEDIRECTORY(LogLevel_DebugBasic, cohorts.WsRequested, dllInstance);
                        }
                    }
                    break;
                case mfr::mfr_path_types::in_package_pvad_area:
                    if (cohorts.map.Valid_mapping == mfr::mfr_enabled_types::enabled)
                    {
                        //// try the redirected path, then package (COW), then don't need native.
                        if (cohorts.map.IsAnExclusionToRedirect == mfr::mfr_exclusion_types::not_excluded && 
                            PathExists(cohorts.WsRedirected.c_str()))
                        {
                            retfinal = WRAPPER_REMOVEDIRECTORY(LogLevel_DebugBasic, cohorts.WsRedirected, dllInstance);
                            return retfinal;
                        }
                        else if (PathExists(cohorts.WsPackage.c_str()))
                        {
                            retfinal = FALSE;
                            SetLastError(ERROR_ACCESS_DENIED);
                            Log(LogLevel_DebugBasic, "[% s % d] RemoveDirectoryFixup: Setting return code to ERROR_ACCESS_DENIED.", g_MfrModuleName, dllInstance);
                            return retfinal;
                        }
                        else
                        {
                            // There isn't such a file anywhere.
                            retfinal = false;
                            SetLastError(ERROR_FILE_NOT_FOUND); // doesn't matter if path or file not found.
                            Log(LogLevel_DebugBasic, "[%s%d] RemoveDirectoryFixup: Setting return code to ERROR_FILE_NOT_FOUND.", g_MfrModuleName, dllInstance);
                            return retfinal;
                        }
                    }
                    break;
                case mfr::mfr_path_types::in_package_vfs_area:
                    if (cohorts.map.Valid_mapping == mfr::mfr_enabled_types::enabled &&
                        cohorts.map.RedirectionFlags == mfr::mfr_redirect_flags::prefer_redirection_local)
                    {
                        // try the redirection path, then the package (COW).
                        if (cohorts.map.IsAnExclusionToRedirect == mfr::mfr_exclusion_types::not_excluded && 
                            PathExists(cohorts.WsRedirected.c_str()))
                        {
                            retfinal = WRAPPER_REMOVEDIRECTORY(LogLevel_DebugBasic, cohorts.WsRedirected, dllInstance);
                            return retfinal;
                        }
                        else if (PathExists(cohorts.WsPackage.c_str()))
                        {
                            retfinal = false;
                            SetLastError(ERROR_ACCESS_DENIED);
                            Log(LogLevel_DebugBasic, "[%s%d] RemoveDirectoryFixup: Setting return code to ERROR_ACCESS_DENIED.", g_MfrModuleName, dllInstance);
                            return retfinal;
                        }
                        else
                        {
                            // There isn't such a file anywhere.  
                            retfinal = false;
                            SetLastError(ERROR_FILE_NOT_FOUND); // not important if file or path
                            Log(LogLevel_DebugBasic, "[%s%d] RemoveDirectoryFixup: Setting return code to ERROR_FILE_NOT_FOUND.", g_MfrModuleName, dllInstance);
                            return retfinal;
                        }
                    }
                    else if (cohorts.map.Valid_mapping == mfr::mfr_enabled_types::enabled &&
                        (cohorts.map.RedirectionFlags == mfr::mfr_redirect_flags::prefer_redirection_containerized ||
                            cohorts.map.RedirectionFlags == mfr::mfr_redirect_flags::prefer_redirection_if_package_vfs))
                    {
                        // try the redirection path, then the package (COW), then native (possibly COW)
                        if (cohorts.map.IsAnExclusionToRedirect == mfr::mfr_exclusion_types::not_excluded && 
                            PathExists(cohorts.WsRedirected.c_str()))
                        {
                            retfinal = WRAPPER_REMOVEDIRECTORY(LogLevel_DebugBasic, cohorts.WsRedirected, dllInstance);
                            return retfinal;
                        }
                        else if (PathExists(cohorts.WsPackage.c_str()))
                        {
                            retfinal = FALSE;
                            SetLastError(ERROR_ACCESS_DENIED);
                            Log(LogLevel_DebugBasic, "[%s%d] RemoveDirectoryFixup: Setting return code to ERROR_ACCESS_DENIED.", g_MfrModuleName, dllInstance);
                            return retfinal;
                        }
                        else if (cohorts.NativeIsValidOptionInScenario &&
                            PathExists(cohorts.WsNative.c_str()))
                        {
                            retfinal = WRAPPER_REMOVEDIRECTORY(LogLevel_DebugBasic, cohorts.WsNative, dllInstance);
                            return retfinal;
                        }
                        else
                        {
                            retfinal = FALSE;
                            SetLastError(ERROR_FILE_NOT_FOUND);
                            Log(LogLevel_DebugBasic, "[%s%d] RemoveDirectoryFixup: Setting return code to ERROR_FILE_NOT_FOUND.", g_MfrModuleName, dllInstance);
                            return retfinal;
                        }
                    }
                    break;
                case mfr::mfr_path_types::in_redirection_area_writablepackageroot:
                    if (cohorts.map.Valid_mapping == mfr::mfr_enabled_types::enabled)
                    {
                        // try the redirected path, then package (COW), then possibly native (Possibly COW).
                        if (cohorts.map.IsAnExclusionToRedirect == mfr::mfr_exclusion_types::not_excluded && 
                            PathExists(cohorts.WsRedirected.c_str()))
                        {
                            retfinal = WRAPPER_REMOVEDIRECTORY(LogLevel_DebugBasic, cohorts.WsRedirected, dllInstance);
                            return retfinal;
                        }
                        else if (PathExists(cohorts.WsPackage.c_str()))
                        {
                            retfinal = FALSE;
                            SetLastError(ERROR_ACCESS_DENIED);
                            Log(LogLevel_DebugBasic, "[%s%d] RemoveDirectoryFixup: Setting return code to ERROR_ACCESS_DENIED.", g_MfrModuleName, dllInstance);
                            return retfinal;
                        }
                        else if (cohorts.NativeIsValidOptionInScenario &&
                            PathExists(cohorts.WsNative.c_str()))
                        {
                            retfinal = WRAPPER_REMOVEDIRECTORY(LogLevel_DebugBasic, cohorts.WsNative, dllInstance);
                            return retfinal;
                        }
                        else
                        {
                            // There isn't such a file anywhere.
                            retfinal = FALSE;
                            SetLastError(ERROR_FILE_NOT_FOUND);
                            Log(LogLevel_DebugBasic, "[%s%d] RemoveDirectoryFixup: Setting return code to ERROR_FILE_NOT_FOUND.", g_MfrModuleName, dllInstance);
                            return retfinal;
                        }
                    }
                    break;
                case mfr::mfr_path_types::in_redirection_area_other:
                    break;
                case mfr::mfr_path_types::is_Protocol:
                case mfr::mfr_path_types::is_DosSpecial:
                case mfr::mfr_path_types::is_Shell:
                case mfr::mfr_path_types::in_other_drive_area:
                case mfr::mfr_path_types::is_UNC_path:
                case mfr::mfr_path_types::unsupported_for_intercepts:
                case mfr::mfr_path_types::unknown:
                default:
                    break;
                }
            }
            else
            {
                // ILV prefers to delete in package when present
                std::wstring usePath = DetermineIlvPathForWriteOperations(LogLevel_DebugIntermediate, cohorts, dllInstance);
                // Local redirection prep not required for remove operation

                retfinal = WRAPPER_REMOVEDIRECTORY(LogLevel_DebugBasic, usePath, dllInstance);
                return retfinal;
            }
        }
    }
    // Fall back to assuming no redirection is necessary if exception
    LOGGED_CATCHHANDLER_MIN(LogLevel_DebugBasic, g_MfrModuleName, dllInstance, L"RemoveDirectory")

    if (pathName != nullptr)
    {
        std::wstring LongRemovingDirectory = MakeLongPath(widen(pathName));
        retfinal = impl::RemoveDirectory(LongRemovingDirectory.c_str());
    }
    else
    {
        SetLastError(ERROR_INVALID_PARAMETER);
        retfinal = 0; // impl::RemoveDirectory(pathName);
    }
    Log(LogLevel_DebugBasic, L"[%s%d] RemoveDirectoryFixup returns 0x%x", g_MfrModuleName, dllInstance, retfinal);
    return retfinal;
}
DECLARE_STRING_FIXUP(impl::RemoveDirectory, RemoveDirectoryFixup);
