//-------------------------------------------------------------------------------------------------------
// Copyright (C) Microsoft Corporation. All rights reserved.
// Copyright (C) TMurgent Technologies, LLP. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.
//-------------------------------------------------------------------------------------------------------

// Microsoft Documentation on this API: https://docs.microsoft.com/en-us/windows/win32/api/winbase/nf-winbase-createdirectory

#if _DEBUG
//#define MOREDEBUG 1
#endif

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// DESIGN NOTE:  It is debatable what return to give when the app asks to create a directory and it is subject
//               to redirection.  It may or may not exist previously in some locations and differently in the 
//               redirection area, so the "correct" return code is debatable.
// 
//               We can provide a generally compatible answer, or success as long as it didn't exist in the redirection
//               area.  Because we always precreate the parent folders, PATH_NOT_FOUND becomes impossible, so either
//               success is returned or ERROR_ALREADY_EXISTS is returned should it already exist in the redirection area.
//               Generally, we think the apps trying to create a directory will ignore the error unless PATH_NOT_FOUND is
//               returned, because they only care that it really was created, making this a decent strategy.  But also 
//               consider that if the directory exists in the package path and the app tried to delete it (but can't 
//               because it is immutable), hiding the ERROR_ALREADY_EXISTS can be beneficial as we would have deleted 
//               the redirected copy and are now creating it.  However if the purpose was to remove the things in the
//               package under that folder we can't remove the package flotsam, so there is no right answer. 
// 
//               The alternative is that we can provide a ERROR_ALREADY_EXISTS if it exists under any of the paths, 
//               whether or not we create the redirected folder.  This might make certain apps work better, but would
//               lead to more work by the app and not necessarily a good outcome.
//
//               The implementation, without the IMPROVE_RETURN_ACCURACY define, follows the first course.
//
//               Turn on the define to get the second behavior.  Consider CreateDirectoryEx which would need a similar
//               strategy if you do.
//   
//               NOTE: In an ILV scenario with traditional redirection, we want to add the directory to the package and not
//                     the redirection area.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#define IMPROVE_RETURN_ACCURACY 1

#include <errno.h>
#include "FunctionImplementations.h"
#include <psf_logging.h>

#include "ManagedPathTypes.h"
#include "PathUtilities.h"
#include "DetermineCohorts.h"
#include "DetermineIlvPaths.h"



#ifdef _M_IX86
#pragma comment(linker, "/EXPORT:CreateDirectoryFixupAnsi_Fixup=impl::_CreateDirectoryFixup.ansi")  // A test to see if exporting these names helps ProcessMonitor stack traces.
#pragma comment(linker, "/EXPORT:CreateDirectoryFixupWide_Fixup=impl::_CreateDirectoryFixup.wide")  // A test to see if exporting these names helps ProcessMonitor stack traces.
#pragma comment(linker, "/EXPORT:WRAPPER_CREATEDIRECTORY=_WRAPPER_CREATEDIRECTORY.wide")
#else
#pragma comment(linker, "/EXPORT:CreateDirectoryFixupAnsi_Fixup=impl::CreateDirectoryFixup.ansi")  // A test to see if exporting these names helps ProcessMonitor stack traces.
#pragma comment(linker, "/EXPORT:CreateDirectoryFixupWide_Fixup=impl::CreateDirectoryFixup.wide")  // A test to see if exporting these names helps ProcessMonitor stack traces.
#pragma comment(linker, "/EXPORT:WRAPPER_CREATEDIRECTORY=WRAPPER_CREATEDIRECTORY.wide")
#endif


BOOL  WRAPPER_CREATEDIRECTORY(Json_Debug_Levels debugRequestLevel, std::wstring theDestinationDirectory, LPSECURITY_ATTRIBUTES securityAttributes, DWORD dllInstance)
{
    std::wstring LongDestinationDirectory = MakeLongPath(theDestinationDirectory);
    BOOL retfinal = impl::CreateDirectoryW(LongDestinationDirectory.c_str(), securityAttributes);
    
    if (retfinal == 0)
    {
        DWORD lastError = GetLastError();
        if (lastError == ERROR_ALREADY_EXISTS)
        {
            Log(debugRequestLevel, L"[%s%d] CreateDirectory returns FAILURE 0x%x GetLastError=ALREADY_EXISTS(0x%x) and file '%s'", g_MfrModuleName, dllInstance, lastError, GetLastError(), LongDestinationDirectory.c_str());
        }
        else if (lastError == ERROR_PATH_NOT_FOUND)
        {
            // This is a failure, but we should never get this because we pre-create the parent folders.
            Log(debugRequestLevel, L"[%s%d] CreateDirectory returns FAILURE 0x%x GetLastError=PATH_NOT_FOUND(0x%x) and file '%s'", g_MfrModuleName, dllInstance, lastError, GetLastError(), LongDestinationDirectory.c_str());
        }
        else if (lastError == ERROR_FILE_NOT_FOUND)
        {
            // This is a failure, but we should never get this because we pre-create the parent folders.
            Log(debugRequestLevel, L"[%s%d] CreateDirectory returns FAILURE 0x%x GetLastError=FILE_NOT_FOUND(0x%x) and file '%s'", g_MfrModuleName, dllInstance, lastError, GetLastError(), LongDestinationDirectory.c_str());
        }
        else
        {
            // Some other error occurred.
            Log(debugRequestLevel, L"[%s%d] CreateDirectory returns FAILURE 0x%x GetLastError=0x%x and file '%s'", g_MfrModuleName, dllInstance, retfinal, lastError, LongDestinationDirectory.c_str());
        }
    }
    else
    {
        Log(debugRequestLevel, L"[%s%d] CreateDirectory returns SUCCESS 0x%x and file '%s'", g_MfrModuleName, dllInstance, retfinal, LongDestinationDirectory.c_str());
    }
    return retfinal; 
}



template <typename CharT>
BOOL __stdcall CreateDirectoryFixup(_In_ const CharT* pathName, _In_opt_ LPSECURITY_ATTRIBUTES securityAttributes) noexcept
{
    DWORD dllInstance = g_InterceptInstance;


    auto guard = g_reentrancyGuard.enter();
    BOOL retfinal;

    try
    {
        if (guard)
        {
            dllInstance = ++g_InterceptInstance;
            std::wstring wPathName = widen(pathName);
            wPathName = AdjustSlashes(wPathName, dllInstance);

            LogString(LogLevel_DebugBasic, g_MfrModuleName, dllInstance, L"CreateDirectoryFixup for path", pathName);
            
            wPathName = AdjustBadUNC(wPathName, dllInstance, L"CreateDirectoryFixup");
            

            // This get is inherently a write operation in all cases.
            // There is no need to COW, just create the redirected folder, but may need to create parent folders first.
            Cohorts cohorts;
            DetermineCohorts(LogLevel_DebugIntermediate, wPathName, &cohorts, dllInstance, L"CreateDirectoryFixup");

            if (!MFRConfiguration.Ilv_Aware || !cohorts.IsPathIlvEligible)
            {
                switch (cohorts.file_mfr.Request_MfrPathType)
                {
                case mfr::mfr_path_types::in_native_area:
                    if (cohorts.map.Valid_mapping == mfr::mfr_enabled_types::enabled &&
                        cohorts.map.RedirectionFlags == mfr::mfr_redirect_flags::prefer_redirection_local)
                    {
                        // try the request path, which must be the local redirected version by definition, and then a package equivalent
                        if (cohorts.map.IsAnExclusionToRedirect == mfr::mfr_exclusion_types::not_excluded && 
                            PathExists(cohorts.WsRedirected.c_str()))
                        {
                            // Still do this to set attributes
                            retfinal = WRAPPER_CREATEDIRECTORY(LogLevel_DebugBasic, cohorts.WsRedirected, securityAttributes, dllInstance);
#if IMPROVE_RETURN_ACCURACY
                            if (!retfinal)
                            {
                                if (PathExists(cohorts.WsPackage.c_str()))
                                {
                                    SetLastError(ERROR_ALREADY_EXISTS);
                                    Log(LogLevel_DebugBasic, "[%s%d] CreateDirectoryFixup: Resetting return code to ERROR_ALREADY_EXISTS.", g_MfrModuleName, dllInstance);
                                }
                            }
#endif
                            return retfinal;
                        }
                        else if (PathExists(cohorts.WsPackage.c_str()))
                        {
                            // COW is not applicable, we don't need to copy the whole directory, just create it.
                            PreCreateFolders(cohorts.WsRedirected.c_str(), dllInstance, L"CreateDirectoryFixup");
                            retfinal = WRAPPER_CREATEDIRECTORY(LogLevel_DebugBasic, cohorts.WsRedirected, securityAttributes, dllInstance);
#if IMPROVE_RETURN_ACCURACY
                            if (!retfinal)
                            {
                                SetLastError(ERROR_ALREADY_EXISTS);
                                Log(LogLevel_DebugBasic, "[%s%d] CreateDirectoryFixup: Resetting return code to ERROR_ALREADY_EXISTS.", g_MfrModuleName, dllInstance);
                            }
#endif
                            return retfinal;
                        }
                        else
                        {
                            // There isn't such a file anywhere.  We want to create the redirection parent folder and let this call against the redirected file to create there.
                            PreCreateFolders(cohorts.WsRedirected.c_str(), dllInstance, L"CreateDirectoryFixup");
                            return WRAPPER_CREATEDIRECTORY(LogLevel_DebugBasic, cohorts.WsRedirected, securityAttributes, dllInstance);
                        }
                    }
                    else if (cohorts.map.Valid_mapping == mfr::mfr_enabled_types::enabled && 
                        (cohorts.map.RedirectionFlags == mfr::mfr_redirect_flags::prefer_redirection_containerized ||
                            cohorts.map.RedirectionFlags == mfr::mfr_redirect_flags::prefer_redirection_if_package_vfs))
                    {
                        // try the redirected path, then package (via COW), then native (possibly via COW).
                        if (cohorts.map.IsAnExclusionToRedirect == mfr::mfr_exclusion_types::not_excluded && 
                            PathExists(cohorts.WsRedirected.c_str()))
                        {
                            retfinal = WRAPPER_CREATEDIRECTORY(LogLevel_DebugBasic, cohorts.WsRedirected, securityAttributes, dllInstance);
#if IMPROVE_RETURN_ACCURACY
                            if (!retfinal)
                            {
                                if (PathExists(cohorts.WsPackage.c_str()) ||
                                    (cohorts.NativeIsValidOptionInScenario && PathExists(cohorts.WsNative.c_str())))
                                {
                                    retfinal = FALSE;
                                    SetLastError(ERROR_ALREADY_EXISTS);
                                    Log(LogLevel_DebugBasic, "[%s%d] CreateDirectoryFixup: Resetting return code to ERROR_ALREADY_EXISTS.", g_MfrModuleName, dllInstance);
                                }
                            }
#endif
                            return retfinal;
                        }
                        else if (PathExists(cohorts.WsPackage.c_str()))
                        {
                            PreCreateFolders(cohorts.WsRedirected.c_str(), dllInstance, L"CreateDirectoryFixup");
                            retfinal = WRAPPER_CREATEDIRECTORY(LogLevel_DebugBasic, cohorts.WsRedirected, securityAttributes, dllInstance);
#if IMPROVE_RETURN_ACCURACY
                            if (!retfinal)
                            {
                                SetLastError(ERROR_ALREADY_EXISTS);
                                Log(LogLevel_DebugBasic, "[%s%d] CreateDirectoryFixup: Resetting return code to ERROR_ALREADY_EXISTS.", g_MfrModuleName, dllInstance);
                            }
#endif
                            return retfinal;
                        }
                        else if (cohorts.NativeIsValidOptionInScenario &&
                            PathExists(cohorts.WsNative.c_str()))
                        {
                            PreCreateFolders(cohorts.WsRedirected.c_str(), dllInstance, L"CreateDirectoryFixup");
                            retfinal = WRAPPER_CREATEDIRECTORY(LogLevel_DebugBasic, cohorts.WsRedirected, securityAttributes, dllInstance);
#if IMPROVE_RETURN_ACCURACY
                            if (!retfinal)
                            {
                                SetLastError(ERROR_ALREADY_EXISTS);
                                Log(LogLevel_DebugBasic, "[%s%d] CreateDirectoryFixup: Resetting return code to ERROR_ALREADY_EXISTS.", g_MfrModuleName, dllInstance);
                            }
#endif
                            return retfinal;
                        }
                        else
                        {
                            // There isn't such a file anywhere.  We want to create the redirection parent folder and let this call against the redirected file to create there.
                            PreCreateFolders(cohorts.WsRedirected.c_str(), dllInstance, L"CreateDirectoryFixup");
                            return WRAPPER_CREATEDIRECTORY(LogLevel_DebugBasic, cohorts.WsRedirected, securityAttributes, dllInstance);
                        }
                    }
                    break;
                case mfr::mfr_path_types::in_package_pvad_area:
                    if (cohorts.map.Valid_mapping == mfr::mfr_enabled_types::enabled)
                    {
                        //// try the redirected path, then package (COW), then don't need native.
                        if (cohorts.map.IsAnExclusionToRedirect == mfr::mfr_exclusion_types::not_excluded && 
                            PathExists(cohorts.WsRedirected.c_str()))
                        {
                            PreCreateFolders(cohorts.WsRedirected.c_str(), dllInstance, L"CreateDirectoryFixup");
                            retfinal = WRAPPER_CREATEDIRECTORY(LogLevel_DebugBasic, cohorts.WsRedirected, securityAttributes, dllInstance);
#if IMPROVE_RETURN_ACCURACY
                            if (!retfinal)
                            {
                                if (PathExists(cohorts.WsPackage.c_str()))
                                {
                                    retfinal = FALSE;
                                    SetLastError(ERROR_ALREADY_EXISTS);
                                    Log(LogLevel_DebugBasic, "[%s%d] CreateDirectoryFixup: Resetting return code to ERROR_ALREADY_EXISTS.", g_MfrModuleName, dllInstance);
                                }
                            }
#endif
                            return retfinal;
                        }
                        else if (PathExists(cohorts.WsPackage.c_str()))
                        {
                            PreCreateFolders(cohorts.WsRedirected.c_str(), dllInstance, L"CreateDirectoryFixup");
                            retfinal = WRAPPER_CREATEDIRECTORY(LogLevel_DebugBasic, cohorts.WsRedirected, securityAttributes, dllInstance);
#if IMPROVE_RETURN_ACCURACY
                            if (!retfinal)
                            {
                                SetLastError(ERROR_ALREADY_EXISTS);
                                Log(LogLevel_DebugBasic, "[%s%d] CreateDirectoryFixup: Resetting return code to ERROR_ALREADY_EXISTS.", g_MfrModuleName, dllInstance);
                            }
#endif
                            return retfinal;
                        }
                        else
                        {
                            // There isn't such a file anywhere.  We want to create the redirection parent folder and let this call against the redirected file to create there.
                            PreCreateFolders(cohorts.WsRedirected.c_str(), dllInstance, L"CreateDirectoryFixup");
                            return WRAPPER_CREATEDIRECTORY(LogLevel_DebugBasic, cohorts.WsRedirected, securityAttributes, dllInstance);
                        }
                    }
                    break;
                case mfr::mfr_path_types::in_package_vfs_area:
                    if (cohorts.map.Valid_mapping == mfr::mfr_enabled_types::enabled &&
                        cohorts.map.RedirectionFlags == mfr::mfr_redirect_flags::prefer_redirection_local)
                    {
                        // try the redirection path, then the package (COW).
                        if (cohorts.map.IsAnExclusionToRedirect == mfr::mfr_exclusion_types::not_excluded && 
                            PathExists(cohorts.WsRedirected.c_str()))
                        {
                            PreCreateFolders(cohorts.WsRedirected.c_str(), dllInstance, L"CreateDirectoryFixup");
                            retfinal = WRAPPER_CREATEDIRECTORY(LogLevel_DebugBasic, cohorts.WsRedirected, securityAttributes, dllInstance);
#if IMPROVE_RETURN_ACCURACY
                            if (!retfinal)
                            {
                                if (PathExists(cohorts.WsPackage.c_str()))
                                {
                                    SetLastError(ERROR_ALREADY_EXISTS);
                                    Log(LogLevel_DebugBasic, "[%s%d] CreateDirectoryFixup: Resetting return code to ERROR_ALREADY_EXISTS.", g_MfrModuleName, dllInstance);
                                }
                            }
#endif
                            return retfinal;
                        }
                        else if (PathExists(cohorts.WsPackage.c_str()))
                        {
                            PreCreateFolders(cohorts.WsRedirected.c_str(), dllInstance, L"CreateDirectoryFixup");
                            retfinal = WRAPPER_CREATEDIRECTORY(LogLevel_DebugBasic, cohorts.WsRedirected, securityAttributes, dllInstance);
#if IMPROVE_RETURN_ACCURACY
                            if (!retfinal)
                            {
                                SetLastError(ERROR_ALREADY_EXISTS);
                                Log(LogLevel_DebugBasic, "[%s%d] CreateDirectoryFixup: Resetting return code to ERROR_ALREADY_EXISTS.", g_MfrModuleName, dllInstance);
                            }
#endif
                        }
                        else
                        {
                            // There isn't such a file anywhere.  We want to create the redirection parent folder and let this call against the redirected file to create there.
                            PreCreateFolders(cohorts.WsRedirected.c_str(), dllInstance, L"CreateDirectoryFixup");
                            return WRAPPER_CREATEDIRECTORY(LogLevel_DebugBasic, cohorts.WsRedirected, securityAttributes, dllInstance);
                        }
                    }
                    else if (cohorts.map.Valid_mapping == mfr::mfr_enabled_types::enabled  &&
                        (cohorts.map.RedirectionFlags == mfr::mfr_redirect_flags::prefer_redirection_containerized ||
                            cohorts.map.RedirectionFlags == mfr::mfr_redirect_flags::prefer_redirection_if_package_vfs))
                    {
                        // try the redirection path, then the package (COW), then native (possibly COW)
                        if (cohorts.map.IsAnExclusionToRedirect == mfr::mfr_exclusion_types::not_excluded && 
                            PathExists(cohorts.WsRedirected.c_str()))
                        {
                            PreCreateFolders(cohorts.WsRedirected.c_str(), dllInstance, L"CreateDirectoryFixup");
                            retfinal = WRAPPER_CREATEDIRECTORY(LogLevel_DebugBasic, cohorts.WsRedirected, securityAttributes, dllInstance);
#if IMPROVE_RETURN_ACCURACY
                            if (!retfinal)
                            {
                                if (PathExists(cohorts.WsPackage.c_str()) ||
                                    PathExists(cohorts.WsNative.c_str()))
                                {
                                    SetLastError(ERROR_ALREADY_EXISTS);
                                    Log(LogLevel_DebugBasic, "[%s%d] CreateDirectoryFixup: Resetting return code to ERROR_ALREADY_EXISTS.", g_MfrModuleName, dllInstance);
                                }
                            }
#endif
                            return retfinal;
                        }
                        else if (PathExists(cohorts.WsPackage.c_str()))
                        {
                            PreCreateFolders(cohorts.WsRedirected.c_str(), dllInstance, L"CreateDirectoryFixup");
                            retfinal = WRAPPER_CREATEDIRECTORY(LogLevel_DebugBasic, cohorts.WsRedirected, securityAttributes, dllInstance);
#if IMPROVE_RETURN_ACCURACY
                            if (!retfinal)
                            {
                                SetLastError(ERROR_ALREADY_EXISTS);
                                Log(LogLevel_DebugBasic, "[%s%d] CreateDirectoryFixup: Resetting return code to ERROR_ALREADY_EXISTS.", g_MfrModuleName, dllInstance);
                            }
#endif
                            return retfinal;
                        }
                        else if (cohorts.NativeIsValidOptionInScenario &&
                            PathExists(cohorts.WsNative.c_str()))
                        {
                            PreCreateFolders(cohorts.WsRedirected.c_str(), dllInstance, L"CreateDirectoryFixup");
                            retfinal = WRAPPER_CREATEDIRECTORY(LogLevel_DebugBasic, cohorts.WsRedirected, securityAttributes, dllInstance);
#if IMPROVE_RETURN_ACCURACY
                            if (!retfinal)
                            {
                                SetLastError(ERROR_ALREADY_EXISTS);
                                Log(LogLevel_DebugBasic, "[%s%d] CreateDirectoryFixup: Resetting return code to ERROR_ALREADY_EXISTS.", g_MfrModuleName, dllInstance);
                            }
#endif
                            return retfinal;
                        }
                        else
                        {
                            // There isn't such a file anywhere.  We want to create the redirection parent folder and let this call against the redirected file to create there.
                            PreCreateFolders(cohorts.WsRedirected.c_str(), dllInstance, L"CreateDirectoryFixup");
                            return WRAPPER_CREATEDIRECTORY(LogLevel_DebugBasic, cohorts.WsRedirected, securityAttributes, dllInstance);
                        }
                    }
                    break;
                case mfr::mfr_path_types::in_redirection_area_writablepackageroot:
                    if (cohorts.map.Valid_mapping == mfr::mfr_enabled_types::enabled)
                    {
                        // try the redirected path, then package (COW), then possibly native (Possibly COW).
                        if (cohorts.map.IsAnExclusionToRedirect == mfr::mfr_exclusion_types::not_excluded && 
                            PathExists(cohorts.WsRedirected.c_str()))
                        {
                            PreCreateFolders(cohorts.WsRedirected.c_str(), dllInstance, L"CreateDirectoryFixup");
                            retfinal = WRAPPER_CREATEDIRECTORY(LogLevel_DebugBasic, cohorts.WsRedirected, securityAttributes, dllInstance);
#if IMPROVE_RETURN_ACCURACY
                            if (!retfinal)
                            {
                                if (PathExists(cohorts.WsPackage.c_str()) ||
                                    PathExists(cohorts.WsNative.c_str()))
                                {
                                    retfinal = FALSE;
                                    SetLastError(ERROR_ALREADY_EXISTS);
                                    Log(LogLevel_DebugBasic, "[%s%d] CreateDirectoryFixup: Resetting return code to ERROR_ALREADY_EXISTS.", g_MfrModuleName, dllInstance);
                                }
                            }
#endif
                            return retfinal;
                        }
                        else if (PathExists(cohorts.WsPackage.c_str()))
                        {
                            PreCreateFolders(cohorts.WsRedirected.c_str(), dllInstance, L"CreateDirectoryFixup");
                            retfinal = WRAPPER_CREATEDIRECTORY(LogLevel_DebugBasic, cohorts.WsRedirected, securityAttributes, dllInstance);
#if IMPROVE_RETURN_ACCURACY
                            if (!retfinal)
                            {
                                SetLastError(ERROR_ALREADY_EXISTS);
                                Log(LogLevel_DebugBasic, "[%s%d] CreateDirectoryFixup: Resetting return code to ERROR_ALREADY_EXISTS.", g_MfrModuleName, dllInstance);
                            }
#endif
                            return retfinal;
                        }
                        else if (cohorts.NativeIsValidOptionInScenario &&
                            PathExists(cohorts.WsNative.c_str()))
                        {
                            PreCreateFolders(cohorts.WsRedirected.c_str(), dllInstance, L"CreateDirectoryFixup");
                            retfinal = WRAPPER_CREATEDIRECTORY(LogLevel_DebugBasic, cohorts.WsRedirected, securityAttributes, dllInstance);
#if IMPROVE_RETURN_ACCURACY
                            if (!retfinal)
                            {
                                SetLastError(ERROR_ALREADY_EXISTS);
                                Log(LogLevel_DebugBasic, "[%s%d] CreateDirectoryFixup: Resetting return code to ERROR_ALREADY_EXISTS.", g_MfrModuleName, dllInstance);
                            }
#endif
                            return retfinal;
                        }
                        else
                        {
                            // There isn't such a file anywhere.  We want to create the redirection parent folder and let this call against the redirected file to create there or update registry.
                            PreCreateFolders(cohorts.WsRedirected.c_str(), dllInstance, L"CreateDirectoryFixup");
                            return WRAPPER_CREATEDIRECTORY(LogLevel_DebugBasic, cohorts.WsRedirected, securityAttributes, dllInstance);
                        }
                    }
                    break;
                case mfr::mfr_path_types::in_redirection_area_other:
                    PreCreateFolders(cohorts.WsRequested.c_str(), dllInstance, L"CreateDirectoryFixup");
                    return WRAPPER_CREATEDIRECTORY(LogLevel_DebugBasic, cohorts.WsRequested, securityAttributes, dllInstance);
                    break;
                case mfr::mfr_path_types::is_Protocol:
                case mfr::mfr_path_types::is_DosSpecial:
                case mfr::mfr_path_types::is_Shell:
                case mfr::mfr_path_types::in_other_drive_area:
                case mfr::mfr_path_types::is_UNC_path:
                case mfr::mfr_path_types::unsupported_for_intercepts:
                case mfr::mfr_path_types::unknown:
                default:
                    break;
                }
            }
            else
            {
                // TODO ISSUE:  App calls to createdirectory C:\Users\username which is an exact-match redirect to local
                //              While we normally want to consider if it is in the package, in this case (because it is a directory and redir to local),
                //              we don't want to pre-create in the redirection area.  In fact, we don't even need to check the package area either in that case.
                //              Just do what was asked (which is probably going to be a failure because it already exists!).
                //              The code below needs some improvement.  
                //              Also CreateDirectoryEx.  
                //              Then think about the file case (which might be OK but definitely not the changes we need here).
                
                //ILV aware
                std::wstring usePath = DetermineIlvPathForWriteOperations(LogLevel_DebugIntermediate, cohorts, dllInstance);
                // In a redirect to local scenario, we are responsible for pre-creating the local parent folders
                // if-and-only-if they are present in the package.
                LogString(LogLevel_DebugBasic, g_MfrModuleName, dllInstance, L"CreateDirectoryFixup IlvAware mode using", usePath.c_str());
                PreCreateLocalFoldersIfNeededForWrite(LogLevel_DebugBasic, usePath, cohorts.WsPackage, dllInstance, L"CreateDirectoryFixup");
                if (!cohorts.NativeIsValidOptionInScenario)
                {
                    PreCreatePackageFoldersIfIlvNeededForWrite(LogLevel_DebugBasic, usePath, dllInstance, L"CreateDirectoryFixup");
                }

                retfinal = WRAPPER_CREATEDIRECTORY(LogLevel_DebugBasic, usePath, securityAttributes, dllInstance);
                return retfinal;
            }
        }
    }
    // Fall back to assuming no redirection is necessary if exception
    LOGGED_CATCHHANDLER_MIN(LogLevel_DebugBasic, g_MfrModuleName, dllInstance, L"CreateDirectoryFixup")

    if (pathName != nullptr)
    {
        std::wstring LongDirectory = MakeLongPath(widen(pathName));
        retfinal = impl::CreateDirectory(LongDirectory.c_str(), securityAttributes);
    }
    else
    {
        SetLastError(ERROR_INVALID_PARAMETER);
        retfinal = 0; // impl::CreateDirectory(pathName, securityAttributes);
    }
    LogString(LogLevel_DebugBasic, g_MfrModuleName, dllInstance, L"CreateDirectoryFixup (unguarded) for path", pathName);
    if (retfinal == 0)
    {
        DWORD eCode = GetLastError();
        if (eCode  == ERROR_ALREADY_EXISTS)
        {
            Log(LogLevel_DebugBasic, L"[%s%d] CreateDirectoryFixup (unguarded) returns 0x%x (ERROR_ALREADY_EXISTS)", g_MfrModuleName, dllInstance, retfinal);
        }
        else
        {
            Log(LogLevel_DebugBasic, L"[%s%d] CreateDirectoryFixup (unguarded) returns 0x%x with error=0x%x", g_MfrModuleName, dllInstance, retfinal, eCode);
        }
    }
    else
    {
        Log(LogLevel_DebugBasic, L"[%s%d] CreateDirectoryFixup (unguarded) returns 0x%x (ERROR_SUCCESS)", g_MfrModuleName, dllInstance, retfinal);
    }
    return retfinal;
}
DECLARE_STRING_FIXUP(impl::CreateDirectory, CreateDirectoryFixup);
