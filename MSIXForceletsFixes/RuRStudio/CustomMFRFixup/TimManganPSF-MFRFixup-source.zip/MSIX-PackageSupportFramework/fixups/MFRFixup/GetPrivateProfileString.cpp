//-------------------------------------------------------------------------------------------------------
// Copyright (C) Microsoft Corporation. All rights reserved.
// Copyright (C) TMurgent Technologies, LLP. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.
//-------------------------------------------------------------------------------------------------------

#include <errno.h>
#include "FunctionImplementations.h"
#include <psf_logging.h>

#include "ManagedPathTypes.h"
#include "PathUtilities.h"
#include "DetermineCohorts.h"
#include "DetermineIlvPaths.h"

// Microsoft documentation: https://docs.microsoft.com/en-us/windows/win32/api/winbase/nf-winbase-getprivateprofilestring

// NOTE: In addition to file based configuration, apps map put this data into the registry.  The app may call this with a null filename, or a filename that does not exist.
//       In that case, we should call the native implementation which will return the registry or default result.

#if _DEBUG
//#define MOREDEBUG 1
#endif

#define WRAPPER_GETPRIVATEPROFILESTRING(theDestinationFilename) \
    { \
        std::wstring LongDestinationFilename = MakeLongPath(theDestinationFilename); \
        if constexpr (psf::is_ansi<CharT>) \
        { \
            retfinal = impl::GetPrivateProfileString(appName, keyName, defaultString, string, stringLength, narrow(LongDestinationFilename.c_str()).c_str()); \
            Log(LogLevel_DebugBasic, L"[%s%d] GetPrivateProfileStringFixup: Ansi Returned length=0x%x from %s", g_MfrModuleName, dllInstance, retfinal, LongDestinationFilename.c_str()); \
            if (retfinal > 0) \
            { \
                LogString(LogLevel_DebugBasic, g_MfrModuleName, dllInstance, L"GetPrivateProfileStringFixup: Ansi Returned string", string); \
            } \
            return retfinal; \
        } \
        else \
        { \
            retfinal = impl::GetPrivateProfileString(appName, keyName, defaultString, string, stringLength, LongDestinationFilename.c_str()); \
            if (retfinal > 0) \
            { \
                Log(LogLevel_DebugBasic, L"[%s%d] GetPrivateProfileStringFixup: Wide Returned length=0x%x from %s", g_MfrModuleName, dllInstance, retfinal, LongDestinationFilename.c_str()); \
                LogString(LogLevel_DebugBasic, g_MfrModuleName, dllInstance, L"GetPrivateProfileStringFixup: Returned string", string); \
            } \
            else \
            { \
                Log(LogLevel_DebugBasic, L"[%s%d] GetPrivateProfileStringFixup: Returned string zero length from %s", g_MfrModuleName, dllInstance, LongDestinationFilename.c_str()); \
            } \
            return retfinal; \
        } \
    }


template <typename CharT>
DWORD __stdcall GetPrivateProfileStringFixup(
    _In_opt_ const CharT* appName,
    _In_opt_ const CharT* keyName,
    _In_opt_ const CharT* defaultString,
    _Out_writes_to_opt_(returnStringSizeInChars, return +1) CharT* string,
    _In_ DWORD stringLength,
    _In_opt_ const CharT* fileName) noexcept
{
    DWORD dllInstance = ++g_InterceptInstance;
    [[maybe_unused]] bool debug = false;
#if _DEBUG
    debug = true;
#endif
    [[maybe_unused]] bool moredebug = false;
#if MOREDEBUG
    moredebug = true;
#endif

    DWORD retfinal;
    auto guard = g_reentrancyGuard.enter();
    try
    {
        if (guard)
        {

            if (fileName != NULL)
            {
                if constexpr (psf::is_ansi<CharT>)
                {
                    if (fileName != NULL)
                    {
                        LogString(LogLevel_DebugBasic, g_MfrModuleName, dllInstance, L"GetPrivateProfileStringFixup (A) for fileName", widen(fileName, CP_ACP).c_str());
                    }
                    else
                    {
                        Log(LogLevel_DebugBasic, L"[%s%d] GetPrivateProfileStringFixup for null file.", g_MfrModuleName, dllInstance);
                    }
                    if (appName != NULL)
                    {

                        LogString(LogLevel_DebugBasic, g_MfrModuleName, dllInstance, L" Section", widen_argument(appName).c_str());
                    }
                    if (keyName != NULL)
                    {
                        LogString(LogLevel_DebugBasic, g_MfrModuleName, dllInstance, L" Key", widen_argument(keyName).c_str());
                    }
                }
                else
                {
                    if (fileName != NULL)
                    {
                        LogString(LogLevel_DebugBasic, g_MfrModuleName, dllInstance, L"GetPrivateProfileStringFixup (W) for fileName", widen(fileName, CP_ACP).c_str());
                    }
                    else
                    {
                        Log(LogLevel_DebugBasic, "[%s%d] GetPrivateProfileStringFixup for null file.", g_MfrModuleName, dllInstance);
                    }
                    if (appName != NULL)
                    {

                        LogString(LogLevel_DebugBasic, g_MfrModuleName, dllInstance, L" Section", appName);
                    }
                    if (keyName != NULL)
                    {
                        LogString(LogLevel_DebugBasic, g_MfrModuleName, dllInstance, L" Key", keyName);
                    }
                }

                // This get is inherently a read-only operation in all cases.
                // We prefer to use the redirecton case, if present.
                std::wstring wfileName = widen(fileName);
                wfileName = AdjustSlashes(wfileName, dllInstance);
                wfileName = AdjustBadUNC(wfileName, dllInstance, L"GetPrivateProfileStringFixup");

                Cohorts cohorts;
                DetermineCohorts(LogLevel_DebugIntermediate, wfileName, &cohorts, dllInstance, L"GetPrivateProfileStringFixup");

                if (!MFRConfiguration.Ilv_Aware)
                {
                    switch (cohorts.file_mfr.Request_MfrPathType)
                    {
                    case mfr::mfr_path_types::in_native_area:
                        if (cohorts.map.Valid_mapping == mfr::mfr_enabled_types::enabled)
                        {
                            switch (cohorts.map.RedirectionFlags)
                            {
                            case mfr::mfr_redirect_flags::prefer_redirection_local:
                                // try the request path, which must be the local redirected version by definition, and then a package equivalent, then default 
                                if (cohorts.map.IsAnExclusionToRedirect == mfr::mfr_exclusion_types::not_excluded && 
                                    PathExists(cohorts.WsRedirected.c_str()))
                                {
                                    WRAPPER_GETPRIVATEPROFILESTRING(cohorts.WsRedirected);
                                }
                                else if (PathExists(cohorts.WsPackage.c_str()))
                                {
                                    WRAPPER_GETPRIVATEPROFILESTRING(cohorts.WsPackage);
                                }
                                else
                                {
                                    // No file, calling allows for default value or to get from registry.
                                    WRAPPER_GETPRIVATEPROFILESTRING(cohorts.WsRequested);
                                }
                                break;
                            case mfr::mfr_redirect_flags::prefer_redirection_containerized:
                            case mfr::mfr_redirect_flags::prefer_redirection_if_package_vfs:
                                // try the redirected path, then package, then native, then default
                                if (cohorts.map.IsAnExclusionToRedirect == mfr::mfr_exclusion_types::not_excluded && 
                                    PathExists(cohorts.WsRedirected.c_str()))
                                {
                                    WRAPPER_GETPRIVATEPROFILESTRING(cohorts.WsRedirected);
                                }
                                else if (PathExists(cohorts.WsPackage.c_str()))
                                {
                                    WRAPPER_GETPRIVATEPROFILESTRING(cohorts.WsPackage);
                                }
                                else if (cohorts.NativeIsValidOptionInScenario &&
                                    PathExists(cohorts.WsNative.c_str()))
                                {
                                    WRAPPER_GETPRIVATEPROFILESTRING(cohorts.WsNative);
                                }
                                else
                                {
                                    // No file, calling allows for default value or to get from registry.
                                    WRAPPER_GETPRIVATEPROFILESTRING(cohorts.WsRequested);
                                }
                                break;
                            case mfr::mfr_redirect_flags::prefer_redirection_none:
                            case mfr::mfr_redirect_flags::disabled:
                            default:
                                // just fall through to unguarded code
                                break;
                            }
                        }
                        break;
                    case mfr::mfr_path_types::in_package_pvad_area:
                        if (cohorts.map.Valid_mapping == mfr::mfr_enabled_types::enabled)
                        {
                            switch (cohorts.map.RedirectionFlags)
                            {
                            case mfr::mfr_redirect_flags::prefer_redirection_local:
                                // not possible, fall through
                                break;
                            case mfr::mfr_redirect_flags::prefer_redirection_containerized:
                            case mfr::mfr_redirect_flags::prefer_redirection_if_package_vfs:
                                //// try the redirected path, then package, then don't need native, so default
                                if (cohorts.map.IsAnExclusionToRedirect == mfr::mfr_exclusion_types::not_excluded && 
                                    PathExists(cohorts.WsRedirected.c_str()))
                                {
                                    WRAPPER_GETPRIVATEPROFILESTRING(cohorts.WsRedirected);
                                }
                                else if (PathExists(cohorts.WsPackage.c_str()))
                                {
                                    WRAPPER_GETPRIVATEPROFILESTRING(cohorts.WsPackage);
                                }
                                else
                                {
                                    // No file, calling allows for default value or to get from registry.
                                    WRAPPER_GETPRIVATEPROFILESTRING(cohorts.WsRequested);
                                }
                                break;
                            case mfr::mfr_redirect_flags::prefer_redirection_none:
                            case mfr::mfr_redirect_flags::disabled:
                            default:
                                // just fall through to unguarded code
                                break;
                            }
                        }
                        break;
                    case mfr::mfr_path_types::in_package_vfs_area:
                        if (cohorts.map.Valid_mapping == mfr::mfr_enabled_types::enabled)
                        {
                            switch (cohorts.map.RedirectionFlags)
                            {
                            case mfr::mfr_redirect_flags::prefer_redirection_local:
                                // try the redirected path, then package path, then default.
                                if (cohorts.map.IsAnExclusionToRedirect == mfr::mfr_exclusion_types::not_excluded && 
                                    PathExists(cohorts.WsRedirected.c_str()))
                                {
                                    WRAPPER_GETPRIVATEPROFILESTRING(cohorts.WsRedirected);
                                }
                                else if (PathExists(cohorts.WsPackage.c_str()))
                                {
                                    WRAPPER_GETPRIVATEPROFILESTRING(cohorts.WsPackage);
                                }
                                else
                                {
                                    // No file, calling allows for default value or to get from registry.
                                    WRAPPER_GETPRIVATEPROFILESTRING(cohorts.WsRequested);
                                }
                                break;
                            case mfr::mfr_redirect_flags::prefer_redirection_containerized:
                            case mfr::mfr_redirect_flags::prefer_redirection_if_package_vfs:
                                // try the redirected path, then package, then native, then default
                                if (cohorts.map.IsAnExclusionToRedirect == mfr::mfr_exclusion_types::not_excluded && 
                                    PathExists(cohorts.WsRedirected.c_str()))
                                {
                                    WRAPPER_GETPRIVATEPROFILESTRING(cohorts.WsRedirected);
                                }
                                else if (PathExists(cohorts.WsPackage.c_str()))
                                {
                                    WRAPPER_GETPRIVATEPROFILESTRING(cohorts.WsPackage);
                                }
                                else if (cohorts.NativeIsValidOptionInScenario &&
                                    PathExists(cohorts.WsNative.c_str()))
                                {
                                    WRAPPER_GETPRIVATEPROFILESTRING(cohorts.WsNative);
                                }
                                else
                                {
                                    // No file, calling allows for default value or to get from registry.
                                    WRAPPER_GETPRIVATEPROFILESTRING(cohorts.WsRequested);
                                }
                                break;
                            case mfr::mfr_redirect_flags::prefer_redirection_none:
                            case mfr::mfr_redirect_flags::disabled:
                            default:
                                // just fall through to unguarded code
                                break;
                            }
                        }
                        break;
                    case mfr::mfr_path_types::in_redirection_area_writablepackageroot:
                        if (cohorts.map.Valid_mapping == mfr::mfr_enabled_types::enabled)
                        {
                            switch (cohorts.map.RedirectionFlags)
                            {
                            case mfr::mfr_redirect_flags::prefer_redirection_local:
                                // not possible
                                break;
                            case mfr::mfr_redirect_flags::prefer_redirection_containerized:
                            case mfr::mfr_redirect_flags::prefer_redirection_if_package_vfs:
                                // try the redirected path, then package, then possibly native, then default.
                                if (cohorts.map.IsAnExclusionToRedirect == mfr::mfr_exclusion_types::not_excluded && 
                                    PathExists(cohorts.WsRedirected.c_str()))
                                {
                                    WRAPPER_GETPRIVATEPROFILESTRING(cohorts.WsRedirected);
                                }
                                else if (PathExists(cohorts.WsPackage.c_str()))
                                {
                                    WRAPPER_GETPRIVATEPROFILESTRING(cohorts.WsPackage);
                                }
                                else if (cohorts.NativeIsValidOptionInScenario &&
                                    PathExists(cohorts.WsNative.c_str()))
                                {
                                    WRAPPER_GETPRIVATEPROFILESTRING(cohorts.WsNative);
                                }
                                else
                                {
                                    // No file, calling allows for default value or to get from registry.
                                    WRAPPER_GETPRIVATEPROFILESTRING(cohorts.WsRequested);
                                }
                                break;
                            case mfr::mfr_redirect_flags::prefer_redirection_none:
                            case mfr::mfr_redirect_flags::disabled:
                            default:
                                // just fall through to unguarded code
                                break;
                            }
                        }
                        break;
                    case mfr::mfr_path_types::in_redirection_area_other:
                        break;
                    case mfr::mfr_path_types::is_Protocol:
                    case mfr::mfr_path_types::is_DosSpecial:
                    case mfr::mfr_path_types::is_Shell:
                    case mfr::mfr_path_types::in_other_drive_area:
                    case mfr::mfr_path_types::is_UNC_path:
                    case mfr::mfr_path_types::unsupported_for_intercepts:
                    case mfr::mfr_path_types::unknown:
                    default:
                        break;
                    }
                }
                else
                {
                    // ILV
                    std::wstring UseFile = DetermineIlvPathForReadOperations(LogLevel_DebugIntermediate, cohorts, dllInstance);
                    // In a redirect to local scenario, we are responsible for determining if source is local or in package
                    UseFile = SelectLocalOrPackageForRead(UseFile, cohorts.WsPackage);

                    WRAPPER_GETPRIVATEPROFILESTRING(UseFile);
                }
            }
            else
            {
                Log(LogLevel_DebugBasic, L"[%s%d] GetPrivateProfileStringFixup: null fileName, don't redirect", g_MfrModuleName, dllInstance);
            }
        }
    }
    // Fall back to assuming no redirection is necessary if exception
    LOGGED_CATCHHANDLER_MIN(LogLevel_DebugBasic, g_MfrModuleName, dllInstance, L"GetPrivateProfileString")

    retfinal = impl::GetPrivateProfileString(appName, keyName, defaultString, string, stringLength, fileName);
    LogString(LogLevel_DebugBasic, g_MfrModuleName, dllInstance, L"GetPrivateProfileString: Returning from unfixed call.", string);
    return retfinal;
}
DECLARE_STRING_FIXUP(impl::GetPrivateProfileString, GetPrivateProfileStringFixup);

