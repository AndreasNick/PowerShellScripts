//-------------------------------------------------------------------------------------------------------
// Copyright (C) TMurgent Technologies, LLP.  All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.
//-------------------------------------------------------------------------------------------------------


#if _DEBUG
//#define MOREDEBUG 1
#endif

#include <errno.h>
#include "FunctionImplementations.h"

#include "ManagedPathTypes.h"
#include "PathUtilities.h"
#include <psf_logging.h>
#include <memory>
#include "FindData3.h"

//Names on non-pairs not working?
#ifdef _M_IX86
#pragma comment(linker, "/EXPORT:FindCloseFixup_Fixup=_FindCloseFixup_Fixup_v")  // A test to see if exporting these names helps ProcessMonitor stack traces.
#else
#pragma comment(linker, "/EXPORT:FindCloseFixup_Fixup=FindCloseFixup_Fixup_v")  // A test to see if exporting these names helps ProcessMonitor stack traces.
#endif

static BOOL __stdcall FindCloseFixup(_Inout_ HANDLE findHandle) noexcept
{
    auto guard = g_reentrancyGuard.enter();
    if (!guard)
    {
        Log(LogLevel_DebugBasic, L"[%s%d] FindCloseFixup", g_MfrModuleName, g_InterceptInstance);
        return impl::FindClose(findHandle);
    }

    DWORD dllInstance = ++g_InterceptInstance;

    if (findHandle == INVALID_HANDLE_VALUE)
    {
        ::SetLastError(ERROR_INVALID_PARAMETER);
        return FALSE;
    }

    auto data3A = reinterpret_cast<FindData3A*>(findHandle);
    auto data3W = reinterpret_cast<FindData3W*>(findHandle);
    if (data3A->RememberedInstance == 0)
    {
        // Possibly not one of ours, or was a case of something like NtQueryDirectoryFile now closing.
        Log(LogLevel_DebugBasic, L"[%s%d] FindCloseFixup (but not from FindFirstFile) handle=0x%x.", g_MfrModuleName,  dllInstance, findHandle);
    }
    else
    {
        Log(LogLevel_DebugBasic, L"[%s%d][%s%d] FindCloseFixup handle=0x%x.", g_MfrModuleName, data3A->RememberedInstance, g_MfrModuleName, dllInstance, findHandle);
    }
    if (data3A && data3A->IsAnsi)
    {
        // This is an ANSI FindData3A structure
        auto data3 = data3A;
        if ((int)data3->RememberedInstance > 70000)
        {
            if (data3->find_handles[Result_Redirected])
            {
                data3->find_handles[Result_Redirected].release();
            }
            if (data3->find_handles[Result_Package])
            {
                data3->find_handles[Result_Package].release();
            }
            if (data3->find_handles[Result_Native])
            {
                data3->find_handles[Result_Native].release();
            }
        }
        else
        {
            // This is a case where we got the guard, but it doesn't look like our FindFirst structure, so maybe from an unhandled NtQueryDirectoryFile or other source, so  impl:FindClose without interpretation?
            impl::FindClose(findHandle);
        }
    }
    else if (data3W && !data3W->IsAnsi)
    {
        // This is a Wide FindData3W structure
        auto data3 = data3W;
        if ((int)data3->RememberedInstance > 70000)
        {
            if (data3->find_handles[Result_Redirected])
            {
                data3->find_handles[Result_Redirected].release();
            }
            if (data3->find_handles[Result_Package])
            {
                data3->find_handles[Result_Package].release();
            }
            if (data3->find_handles[Result_Native])
            {
                data3->find_handles[Result_Native].release();
            }
        }
        else
        {
            // This is a case where we got the guard, but it doesn't look like our FindFirst structure, so maybe from an unhandled NtQueryDirectoryFile or other source, so  impl:FindClose without interpretation?
            impl::FindClose(findHandle);
        }
    }
    ::SetLastError(ERROR_SUCCESS);
    return TRUE;
}
DECLARE_FIXUP(impl::FindClose, FindCloseFixup);
