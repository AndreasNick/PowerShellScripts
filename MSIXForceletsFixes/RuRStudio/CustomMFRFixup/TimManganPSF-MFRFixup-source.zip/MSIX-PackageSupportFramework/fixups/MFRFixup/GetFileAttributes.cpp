//-------------------------------------------------------------------------------------------------------
// Copyright (C) Microsoft Corporation. All rights reserved.
// Copyright (C) TMurgent Technologies, LLP. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.
//-------------------------------------------------------------------------------------------------------


#if _DEBUG
//#define MOREDEBUG 1
#endif

#include <errno.h>
#include "FunctionImplementations.h"
#include <psf_logging.h>

#include "ManagedPathTypes.h"
#include "PathUtilities.h"
#include "DetermineCohorts.h"
#include "DetermineILVpaths.h"

//#define DEBUGPATHTESTING 1
#include "DebugPathTesting.h"


#ifdef _M_IX86
#pragma comment(linker, "/EXPORT:GetFileAttributesFixupAnsi_Fixup=impl::_GetFileAttributesFixup.ansi")  // A test to see if exporting these names helps ProcessMonitor stack traces.
#pragma comment(linker, "/EXPORT:GetFileAttributesFixupWide_Fixup=impl::_GetFileAttributesFixup.wide")  // A test to see if exporting these names helps ProcessMonitor stack traces.
#else
#pragma comment(linker, "/EXPORT:GetFileAttributesFixupAnsi_Fixup=impl::GetFileAttributesFixup.ansi")  // A test to see if exporting these names helps ProcessMonitor stack traces.
#pragma comment(linker, "/EXPORT:GetFileAttributesFixupWide_Fixup=impl::GetFileAttributesFixup.wide")  // A test to see if exporting these names helps ProcessMonitor stack traces.
#endif


#define WRAPPER_GETFILEATTRIBUTES(theDestinationFilename,  wsWhich) \
    { \
        std::wstring LongDestinationFilename = MakeLongPath(theDestinationFilename); \
        retfinal = impl::GetFileAttributesW(LongDestinationFilename.c_str()); \
        DWORD error = GetLastError(); \
        if (retfinal != INVALID_FILE_ATTRIBUTES) \
        { \
            Log(LogLevel_DebugBasic, L"[%s%d] GetFileAttributesFixup returns SUCCESS and Attr 0x%x on file '%s'", g_MfrModuleName, dllInstance,  retfinal, LongDestinationFilename.c_str()); \
            SetLastError(0); \
            return retfinal; \
        } \
        if (error == ERROR_FILE_NOT_FOUND) \
        { \
            anyFileNotFound = true; \
        } \
        else if (error == ERROR_PATH_NOT_FOUND) \
        { \
            anyPathNotFound = true; \
        } \
        Log(LogLevel_DebugBasic, "[%s%d] GetFileAttributesFixup FAILED 0x%x for %s and file %s.", g_MfrModuleName, dllInstance, error, wsWhich, LongDestinationFilename.c_str()); \
    }

template <typename CharT>
DWORD __stdcall GetFileAttributesFixup(_In_ const CharT* fileName) noexcept
{
    DWORD dllInstance = g_InterceptInstance;
    DWORD retfinal;
    auto guard = g_reentrancyGuard.enter();
    try
    {
        if (guard)
        {
            dllInstance = ++g_InterceptInstance;
            std::wstring wfileName = widen(fileName);
            wfileName = AdjustSlashes(wfileName, dllInstance);


            if constexpr (psf::is_ansi<CharT>)
            {
                LogString(LogLevel_DebugBasic, g_MfrModuleName, dllInstance, L"GetFileAttributesFixupA for fileName", wfileName.c_str());
            }
            else
            {
                LogString(LogLevel_DebugBasic, g_MfrModuleName, dllInstance, L"GetFileAttributesFixupW for fileName", wfileName.c_str());

            }

            wfileName = AdjustBadUNC(wfileName, dllInstance, L"GetFileAttributesFixup");
            

#if DEBUGPATHTESTING
            if (wfileName.compare(L"C:\\Program Files\\PlaceholderTest\\Placeholder.txt") == 0)
            {
                DebugPathTesting(dllInstance);
            }
#endif
            // This get is inherently a read-only operation in all cases.
            // We prefer to use the redirection case, if present.
            Cohorts cohorts;
            DetermineCohorts(LogLevel_DebugIntermediate, wfileName, &cohorts, dllInstance, L"GetAttributesFixup");

            bool anyFileNotFound = false;
            bool anyPathNotFound = false;
            

            if (!MFRConfiguration.Ilv_Aware)
            {
                switch (cohorts.file_mfr.Request_MfrPathType)
                {
                case mfr::mfr_path_types::in_native_area:
                    if (cohorts.map.Valid_mapping == mfr::mfr_enabled_types::enabled)
                    {
                        switch (cohorts.map.RedirectionFlags)
                        {
                        case mfr::mfr_redirect_flags::prefer_redirection_local:
                            if (cohorts.map.IsAnExclusionToRedirect == mfr::mfr_exclusion_types::not_excluded)
                            {
                                // try the request path, which must be the local redirected version by definition, and then a package equivalent
                                // This wrapper is a macro returns if successful; we try to avoid checking the same path twice.
                                WRAPPER_GETFILEATTRIBUTES(cohorts.WsRedirected,  L"WsRedirected");  // returns if successful.                                
                            
                                if (!cohorts.WsPackage.compare(cohorts.WsRedirected))
                                {
                                    WRAPPER_GETFILEATTRIBUTES(cohorts.WsPackage, L"WsPackage");  // returns if successful.
                                }
                                if (!cohorts.WsRequested.compare(cohorts.WsRedirected) &&
                                    !cohorts.WsRequested.compare(cohorts.WsPackage))
                                {
                                    WRAPPER_GETFILEATTRIBUTES(cohorts.WsRequested, L"WsRequested");   // returns if successful.
                                }
                            }
                            else
                            {
                                WRAPPER_GETFILEATTRIBUTES(cohorts.WsPackage, L"WsPackage");  // returns if successful.

                                if (cohorts.WsRequested.compare(cohorts.WsPackage)!= 0)
                                {
                                    WRAPPER_GETFILEATTRIBUTES(cohorts.WsRequested, L"WsRequested");   // returns if successful.
                                }
                            }

                            // Everything failed if here
                            if (anyFileNotFound)
                            {
                                SetLastError(ERROR_FILE_NOT_FOUND);
                            }
                            else if (anyPathNotFound)
                            {
                                SetLastError(ERROR_PATH_NOT_FOUND);
                            }
                            Log(LogLevel_DebugBasic, L"[%s%d] GetFileAttributes: returns with result 0x%x and error =0x%x", g_MfrModuleName, dllInstance, retfinal, GetLastError());
                            return retfinal;
                        case mfr::mfr_redirect_flags::prefer_redirection_containerized:
                        case mfr::mfr_redirect_flags::prefer_redirection_if_package_vfs:
                            if (cohorts.map.IsAnExclusionToRedirect == mfr::mfr_exclusion_types::not_excluded)
                            {
                                // try the redirected path, then package, then native.
                                WRAPPER_GETFILEATTRIBUTES(cohorts.WsRedirected, L"WsRedirected");   // returns if successful.
                            
                                if (cohorts.WsPackage.compare(cohorts.WsRedirected) != 0)
                                {
                                    WRAPPER_GETFILEATTRIBUTES(cohorts.WsPackage, L"WsPackage");   // returns if successful.
                                }
                                if (cohorts.WsNative.compare(cohorts.WsRedirected) != 0 &&
                                    cohorts.WsNative.compare(cohorts.WsPackage) != 0)
                                {
                                    WRAPPER_GETFILEATTRIBUTES(cohorts.WsNative, L"WsNative");   // returns if successful.
                                }
                            }
                            else
                            {
                                WRAPPER_GETFILEATTRIBUTES(cohorts.WsPackage, L"WsPackage");   // returns if successful.

                                if (cohorts.WsNative.compare(cohorts.WsPackage) != 0)
                                {
                                    WRAPPER_GETFILEATTRIBUTES(cohorts.WsNative, L"WsNative");   // returns if successful.
                                }
                            }

                            // All failed if here
                            if (anyFileNotFound)
                            {
                                SetLastError(ERROR_FILE_NOT_FOUND);
                            }
                            else if (anyPathNotFound)
                            {
                                SetLastError(ERROR_PATH_NOT_FOUND);
                            }
                            Log(LogLevel_DebugBasic, L"[%s%d] GetFileAttributes: returns with result 0x%x and error =0x%x", g_MfrModuleName, dllInstance, retfinal, GetLastError());
                            return retfinal;
                        case mfr::mfr_redirect_flags::prefer_redirection_none:
                        case mfr::mfr_redirect_flags::disabled:
                        default:
                            // just fall through to unguarded code
                            break;
                        }
                    }
                    break;
                case mfr::mfr_path_types::in_package_pvad_area:
                    /// NOTE: Ilv does not allow accessing PVAD files in the package.  PERIOD!!!  So this call will always fail.
                    if (cohorts.map.Valid_mapping == mfr::mfr_enabled_types::enabled)
                    {
                        if (cohorts.map.IsAnExclusionToRedirect == mfr::mfr_exclusion_types::not_excluded)
                        {
                            Log(LogLevel_DebugIntermediate, L"[%s%d] GetFileAttributes: try redirected... ", g_MfrModuleName, dllInstance);
                            //// try the redirected path, then package, then don't need native.
                            WRAPPER_GETFILEATTRIBUTES(cohorts.WsRedirected, L"WsRedirected");   // returns if successful.
                        }
                        Log(LogLevel_DebugIntermediate, L"[%s%d] GetFileAttributes: still here, try package... ", g_MfrModuleName, dllInstance);
                        WRAPPER_GETFILEATTRIBUTES(cohorts.WsPackage, L"WsPackage");   // returns if successful.
                        Log(LogLevel_DebugIntermediate, L"[%s%d] GetFileAttributes: still here, try package... ", g_MfrModuleName, dllInstance);

                        // Both failed if here
                        if (anyFileNotFound)
                        {
                            SetLastError(ERROR_FILE_NOT_FOUND);
                        }
                        else if (anyPathNotFound)
                        {
                            SetLastError(ERROR_PATH_NOT_FOUND);
                        }
                        Log(LogLevel_DebugBasic, L"[%s%d] GetFileAttributes: returns with result 0x%x and error =0x%x", g_MfrModuleName, dllInstance, retfinal, GetLastError());
                        return retfinal;
                    }
                    break;
                case mfr::mfr_path_types::in_package_vfs_area:
                    if (cohorts.map.Valid_mapping == mfr::mfr_enabled_types::enabled)
                    {
                        switch (cohorts.map.RedirectionFlags)
                        {
                        case mfr::mfr_redirect_flags::prefer_redirection_local:
                            if (cohorts.map.IsAnExclusionToRedirect == mfr::mfr_exclusion_types::not_excluded)
                            {
                                WRAPPER_GETFILEATTRIBUTES(cohorts.WsRedirected, L"WsRedirected");   // returns if successful.                              
                                if (cohorts.WsPackage.compare(cohorts.WsRedirected) != 0)
                                {
                                    WRAPPER_GETFILEATTRIBUTES(cohorts.WsPackage, L"WsPackage");   // returns if successful.
                                }
                            }
                            else
                            {
                                WRAPPER_GETFILEATTRIBUTES(cohorts.WsPackage, L"WsPackage");   // returns if successful.
                            }


                            // Both failed if here
                            if (anyFileNotFound)
                            {
                                SetLastError(ERROR_FILE_NOT_FOUND);
                            }
                            else if (anyPathNotFound)
                            {
                                SetLastError(ERROR_PATH_NOT_FOUND);
                            }
                            Log(LogLevel_DebugBasic, L"[%s%d] GetFileAttributes: returns with result 0x%x and error =0x%x", g_MfrModuleName, dllInstance, retfinal, GetLastError());
                            return retfinal;
                        case mfr::mfr_redirect_flags::prefer_redirection_containerized:
                        case mfr::mfr_redirect_flags::prefer_redirection_if_package_vfs:
                            if (cohorts.map.IsAnExclusionToRedirect == mfr::mfr_exclusion_types::not_excluded)
                            {
                                // try the redirected path, then package, then native.
                                WRAPPER_GETFILEATTRIBUTES(cohorts.WsRedirected, L"WsRedirected");  // returns if successful.
                                if (cohorts.WsPackage.compare(cohorts.WsRedirected)!=0)
                                {
                                    WRAPPER_GETFILEATTRIBUTES(cohorts.WsPackage, L"WsPackage");  // returns if successful.
                                }
                                if (cohorts.WsNative.compare(cohorts.WsRedirected) != 0 &&
                                    cohorts.WsNative.compare(cohorts.WsPackage) != 0)
                                {
                                    WRAPPER_GETFILEATTRIBUTES(cohorts.WsNative, L"WsNative");  // returns if successful.
                                }
                            }
                            else
                            {

                                WRAPPER_GETFILEATTRIBUTES(cohorts.WsPackage, L"WsPackage");  // returns if successful.
                                if (cohorts.WsNative.compare(cohorts.WsPackage) != 0)
                                {
                                    WRAPPER_GETFILEATTRIBUTES(cohorts.WsNative, L"WsNative");  // returns if successful.
                                }
                            }

                            // All failed if here
                            if (anyFileNotFound)
                            {
                                SetLastError(ERROR_FILE_NOT_FOUND);
                            }
                            else if (anyPathNotFound)
                            {
                                SetLastError(ERROR_PATH_NOT_FOUND);
                            }
                            Log(LogLevel_DebugBasic, L"[%s%d] GetFileAttributes: returns with result 0x%x and error =0x%x", g_MfrModuleName, dllInstance, retfinal, GetLastError());
                            return retfinal;
                        case mfr::mfr_redirect_flags::prefer_redirection_none:
                        case mfr::mfr_redirect_flags::disabled:
                        default:
                            // just fall through to unguarded code
                            break;
                        }
                    }
                    break;
                case mfr::mfr_path_types::in_redirection_area_writablepackageroot:
                    if (cohorts.map.Valid_mapping == mfr::mfr_enabled_types::enabled)
                    {
                        switch (cohorts.map.RedirectionFlags)
                        {
                        case mfr::mfr_redirect_flags::prefer_redirection_local:
                            // not possible
                            break;
                        case mfr::mfr_redirect_flags::prefer_redirection_containerized:
                        case mfr::mfr_redirect_flags::prefer_redirection_if_package_vfs:
                            if (cohorts.map.IsAnExclusionToRedirect == mfr::mfr_exclusion_types::not_excluded)
                            {
                                // try the redirected path, then package, then native if relevant.
                                WRAPPER_GETFILEATTRIBUTES(cohorts.WsRedirected, L"WsRedirected");  // returns if successful.
                                if (cohorts.WsPackage.compare(cohorts.WsRedirected) != 0)
                                {
                                    WRAPPER_GETFILEATTRIBUTES(cohorts.WsPackage, L"WsPackage");  // returns if successful.
                                }
                                if (cohorts.NativeIsValidOptionInScenario)
                                {
                                    if (cohorts.WsNative.compare(cohorts.WsRedirected) !=0 &&
                                        cohorts.WsNative.compare(cohorts.WsPackage) != 0)
                                    {
                                        WRAPPER_GETFILEATTRIBUTES(cohorts.WsNative, L"WsNative");  // returns if successful.
                                    }
                                }
                            }
                            else
                            {
                                WRAPPER_GETFILEATTRIBUTES(cohorts.WsPackage, L"WsPackage");  // returns if successful.

                                if (cohorts.NativeIsValidOptionInScenario)
                                {
                                    WRAPPER_GETFILEATTRIBUTES(cohorts.WsNative,  L"WsNative");  // returns if successful.
                                }
                            }

                            // all failed if still here
                            if (anyFileNotFound)
                            {
                                SetLastError(ERROR_FILE_NOT_FOUND);
                            }
                            else if (anyPathNotFound)
                            {
                                SetLastError(ERROR_PATH_NOT_FOUND);
                            }
                            Log(LogLevel_DebugBasic, "[%s%d] GetFileAttributes: returns with result 0x%x and error =0x%x", g_MfrModuleName, dllInstance, retfinal, GetLastError());
                            return retfinal;
                        case mfr::mfr_redirect_flags::prefer_redirection_none:
                        case mfr::mfr_redirect_flags::disabled:
                        default:
                            break;
                        }
                    }
                    break;
                case mfr::mfr_path_types::in_redirection_area_other:
                    break;
                case mfr::mfr_path_types::is_Protocol:
                case mfr::mfr_path_types::is_DosSpecial:
                case mfr::mfr_path_types::is_Shell:
                case mfr::mfr_path_types::in_other_drive_area:
                case mfr::mfr_path_types::is_UNC_path:
                case mfr::mfr_path_types::unsupported_for_intercepts:
                case mfr::mfr_path_types::unknown:
                default:
                    break;
                }
            }
            else
            {
                // ILV
                std::wstring UseFile = DetermineIlvPathForReadOperations(LogLevel_DebugIntermediate, cohorts, dllInstance);
                // In a redirect to local scenario, we are responsible for determining if source is local or in package
                Log(LogLevel_DebugBasic, "[%s%d] GetFileAttributes: in ILV Mode using %s", g_MfrModuleName, dllInstance, UseFile.c_str());
                UseFile = SelectLocalOrPackageForRead(UseFile, cohorts.WsPackage);
                Log(LogLevel_DebugBasic, L"[%s%d] GetFileAttributes: in ILV Mode now using %s", g_MfrModuleName, dllInstance, UseFile.c_str());
                WRAPPER_GETFILEATTRIBUTES(UseFile, L"IlvMode");  // returns if successful.
                return retfinal;
            }
        }
    }
    // Fall back to assuming no redirection is necessary if exception
    LOGGED_CATCHHANDLER_MIN(LogLevel_DebugBasic, g_MfrModuleName, dllInstance, L"GetFileAttributes")


    if (fileName != nullptr)
    {
        std::wstring LongFileName = MakeLongPath(widen(fileName));
        retfinal = impl::GetFileAttributes(LongFileName.c_str());
    }
    else
    {
        SetLastError(ERROR_INVALID_PARAMETER);
        retfinal = INVALID_FILE_ATTRIBUTES; //impl::GetFileAttributes(fileName);
    }
    Log(LogLevel_DebugBasic, L"[%s%d] GetFileAttributes: returns retfinal=%d", g_MfrModuleName, dllInstance, retfinal);
    if (retfinal == INVALID_FILE_ATTRIBUTES)
    {
        Log(LogLevel_DebugBasic, L"[%s%d] GetFileAttributes: No Redirect returns GetLastError=0x%x", g_MfrModuleName, dllInstance, GetLastError());
    }
    return retfinal;
}
DECLARE_STRING_FIXUP(impl::GetFileAttributes, GetFileAttributesFixup);

