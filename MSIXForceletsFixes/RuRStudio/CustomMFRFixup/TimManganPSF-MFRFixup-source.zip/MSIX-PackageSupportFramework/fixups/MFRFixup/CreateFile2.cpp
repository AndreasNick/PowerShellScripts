//-------------------------------------------------------------------------------------------------------
// Copyright (C) Microsoft Corporation. All rights reserved.
// Copyright (C) TMurgent Technologies, LLP. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.
//-------------------------------------------------------------------------------------------------------

// Microsoft Documentation on this API: https://docs.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-createfile2

#include <errno.h>
#include "FunctionImplementations.h"
#include <psf_logging.h>

#include "ManagedPathTypes.h"
#include "PathUtilities.h"
#include "DetermineCohorts.h"
#include "DetermineIlvPaths.h"
#include "Detect_Pipe.h"
#include "..\CommonSrc\findStringIC.h"


#ifdef _M_IX86
#pragma comment(linker, "/EXPORT:CreateFile2Fixup_Fixup=_CreateFile2Fixup_Fixup_v")  // A test to see if exporting these names helps ProcessMonitor stack traces.
#else
#pragma comment(linker, "/EXPORT:CreateFile2Fixup_Fixup=CreateFile2Fixup_Fixup_v")  // A test to see if exporting these names helps ProcessMonitor stack traces.
#endif

HANDLE  WRAPPER_CREATEFILE2(Json_Debug_Levels debugRequestLevel, 
                            std::wstring theDestinationFile,
                            _In_ DWORD desiredAccess,
                            _In_ DWORD shareMode,
                            _In_ DWORD creationDisposition,
                            _In_opt_ LPCREATEFILE2_EXTENDED_PARAMETERS createExParams,
                            DWORD dllInstance)
{
    std::wstring LongDestinationFile = MakeLongPath(theDestinationFile);
    HANDLE retfinal = impl::CreateFile2(LongDestinationFile.c_str(), desiredAccess, shareMode, creationDisposition, createExParams);
    if (retfinal == INVALID_HANDLE_VALUE)
    {
        Log(debugRequestLevel, L"[%s%d] CreateFile2 returns FAILURE 0x%x on file '%s'", g_MfrModuleName, dllInstance, GetLastError(), LongDestinationFile.c_str());
    }
    else
    {
        Log(debugRequestLevel, L"[%s%d] CreateFile2 returns handle 0x%x and file '%s'", g_MfrModuleName, dllInstance, retfinal, LongDestinationFile.c_str());
    }
    return retfinal;
}


HANDLE __stdcall CreateFile2Fixup(
    _In_ LPCWSTR fileName,
    _In_ DWORD desiredAccess,
    _In_ DWORD shareMode,
    _In_ DWORD creationDisposition,
    _In_opt_ LPCREATEFILE2_EXTENDED_PARAMETERS createExParams) noexcept
{
    DWORD dllInstance = g_InterceptInstance;


    auto guard = g_reentrancyGuard.enter();
    HANDLE retfinal;


    try
    {
        if (guard)
        {
            dllInstance = ++g_InterceptInstance;
            std::wstring wPathName = fileName;
            wPathName = AdjustSlashes(wPathName, dllInstance);
            wPathName = AdjustLocalPipeName(wPathName);

            LogString(LogLevel_DebugBasic, g_MfrModuleName, dllInstance, L"CreateFile2Fixup for ", fileName);
            Log(LogLevel_DebugBasic, L"[%s%d]        DesiredAccess %s", g_MfrModuleName, dllInstance, Log_DesiredAccess(desiredAccess).c_str());
            Log(LogLevel_DebugBasic, L"[%s%d]        ShareMode %s", g_MfrModuleName, dllInstance, Log_ShareMode(shareMode).c_str());
            Log(LogLevel_DebugBasic, L"[%s%d]        creationDisposition %s", g_MfrModuleName, dllInstance, Log_CreationDisposition(creationDisposition).c_str());
            if (createExParams)
            {
                Log(LogLevel_DebugBasic, L"[%s%d]        flags %s", g_MfrModuleName, dllInstance, Log_FlagsAndAttributes(LogLevel_None, createExParams->dwFileFlags).c_str());
                Log(LogLevel_DebugBasic, L"[%s%d]        Attributes %s", g_MfrModuleName, dllInstance, Log_FlagsAndAttributes(LogLevel_None, createExParams->dwFileAttributes).c_str());
            }


            wPathName = AdjustBadUNC(wPathName, dllInstance, L"CreateFile2Fixup");
            

            bool IsAWriteCase;
            bool IsPossibleDirectoryCase;
            if (createExParams)
            {
                IsAWriteCase = IsCreateForChange(desiredAccess, creationDisposition, createExParams->dwFileFlags);
                IsPossibleDirectoryCase = IsPossibleCreateForDirectory(desiredAccess, creationDisposition, createExParams->dwFileFlags);
            }
            else
            {
                IsAWriteCase = IsCreateForChange(desiredAccess, creationDisposition, 0);
                IsPossibleDirectoryCase = IsPossibleCreateForDirectory(desiredAccess, creationDisposition, 0);
            }
            


#if NOTOBSOLETE
            if (!IsAWriteCase)
            {
                // Windows Forms apps can use System.Configuration to store settings in their exe.Config file.  The Save method ends up making calls to
                // System.Security.AccessControl.FileSecurity to change the file attributes and if this is a package file it will cause an exception.
                // An example of this is the application mRemoteNG.  We can avoid this by detecting the file at opening and make it do a copy to start with.
                if (IsSpecialCaseforChange(wPathName))
                {
                    IsAWriteCase = true;
                }
            }
#endif

            Log(LogLevel_DebugBasic, L"[%s%d] CreateFile2Fixup: Could be a write operation=%d", g_MfrModuleName, dllInstance, IsAWriteCase);
            Log(LogLevel_DebugBasic, L"[%s%d] CreateFile2Fixup: Is possibly a directory operation=%d", g_MfrModuleName, dllInstance, IsPossibleDirectoryCase);

            // This get is may or may not be a write operation.
            // There may be a need to COW, jand may need to create parent folders in redirection area first.
            Cohorts cohorts;
            DetermineCohorts(LogLevel_DebugMaximum, wPathName, &cohorts, dllInstance, L"CreateFile2Fixup");

            LogString(LogLevel_DebugIntermediate, g_MfrModuleName, dllInstance, L"CreateFileFixup: Cohort redirection", cohorts.WsRedirected.c_str());
            LogString(LogLevel_DebugIntermediate, g_MfrModuleName, dllInstance, L"CreateFileFixup: Cohort package", cohorts.WsPackage.c_str());
            LogString(LogLevel_DebugIntermediate, g_MfrModuleName, dllInstance, L"CreateFileFixup: Cohort native", cohorts.WsNative.c_str());
            Log(LogLevel_DebugBasic, L"[%s%d] CreateFile2Fixup: MfrPathType=%s", g_MfrModuleName, dllInstance, MfrFlagTypesString(cohorts.file_mfr.Request_MfrPathType));
            
            if (!MFRConfiguration.Ilv_Aware)
            {
                switch (cohorts.file_mfr.Request_MfrPathType)
                {
                case mfr::mfr_path_types::in_native_area:
                    if (cohorts.map.Valid_mapping == mfr::mfr_enabled_types::enabled &&
                        cohorts.map.RedirectionFlags == mfr::mfr_redirect_flags::prefer_redirection_local)
                    {
                        // try the request path, which must be the local redirected version by definition, and then a package equivalent
                        if (cohorts.map.IsAnExclusionToRedirect == mfr::mfr_exclusion_types::not_excluded && 
                            PathExists(cohorts.WsRedirected.c_str()))
                        {
                            retfinal = WRAPPER_CREATEFILE2(LogLevel_DebugBasic, cohorts.WsRedirected, desiredAccess, shareMode, creationDisposition, createExParams, dllInstance);
                            return retfinal;
                        }
                        if (cohorts.WsPackage.compare(cohorts.WsRedirected) != 0 &&
                            PathExists(cohorts.WsPackage.c_str()))
                        {
                            if (IsAWriteCase)
                            {
                                // COW is applicable first.
                                if (Cow(LogLevel_DebugBasic, cohorts.WsPackage, cohorts.WsRedirected, dllInstance, L"CreateFile2Fixup"))
                                {
                                    //PreCreateFolders(testWsRedirected.c_str(), dllInstance, L"CreateFileFixup");
                                    retfinal = WRAPPER_CREATEFILE2(LogLevel_DebugBasic, cohorts.WsRedirected, desiredAccess, shareMode, creationDisposition, createExParams, dllInstance);
                                    return retfinal;
                                }
                                else
                                {
                                    retfinal = WRAPPER_CREATEFILE2(LogLevel_DebugBasic, cohorts.WsPackage, desiredAccess, shareMode, creationDisposition, createExParams, dllInstance);
                                    return retfinal;
                                }
                            }
                            else
                            {
                                retfinal = WRAPPER_CREATEFILE2(LogLevel_DebugBasic, cohorts.WsPackage, desiredAccess, shareMode, creationDisposition, createExParams, dllInstance);
                                return retfinal;
                            }
                        }
                        // There isn't such a file anywhere.  We want to create the redirection parent folder and let this call against the redirected file to create there.
                        PreCreateFolders(cohorts.WsRedirected.c_str(), dllInstance, L"CreateFile2Fixup");
                        retfinal = WRAPPER_CREATEFILE2(LogLevel_DebugBasic, cohorts.WsRedirected, desiredAccess, shareMode, creationDisposition, createExParams, dllInstance);
                        return retfinal;
                    }
                    else if (cohorts.map.Valid_mapping == mfr::mfr_enabled_types::enabled &&
                        (cohorts.map.RedirectionFlags == mfr::mfr_redirect_flags::prefer_redirection_containerized ||
                            cohorts.map.RedirectionFlags == mfr::mfr_redirect_flags::prefer_redirection_if_package_vfs))
                    {
                        // TODO: Consider if this is a directory, ala CreateFile implementation for this case
                        // 
                        

                        // try the redirected path, then package (via COW), then native (possibly via COW).
                        if (cohorts.map.IsAnExclusionToRedirect == mfr::mfr_exclusion_types::not_excluded && 
                            PathExists(cohorts.WsRedirected.c_str()))
                        {
                            retfinal = WRAPPER_CREATEFILE2(LogLevel_DebugBasic, cohorts.WsRedirected, desiredAccess, shareMode, creationDisposition, createExParams, dllInstance);
                            return retfinal;
                        }
                        if (cohorts.WsPackage.compare(cohorts.WsRedirected) != 0 &&
                            PathExists(cohorts.WsPackage.c_str()))
                        {
                            if (IsAWriteCase)
                            {
                                // COW is applicable first.
                                if (Cow(LogLevel_DebugBasic, cohorts.WsPackage, cohorts.WsRedirected, dllInstance, L"CreateFile2Fixup"))
                                {
                                    //PreCreateFolders(testWsRedirected.c_str(), dllInstance, L"CreateFileFixup");
                                    retfinal = WRAPPER_CREATEFILE2(LogLevel_DebugBasic, cohorts.WsRedirected, desiredAccess, shareMode, creationDisposition, createExParams, dllInstance);
                                    return retfinal;
                                }
                                else
                                {
                                    retfinal = WRAPPER_CREATEFILE2(LogLevel_DebugBasic, cohorts.WsPackage, desiredAccess, shareMode, creationDisposition, createExParams, dllInstance);
                                    return retfinal;
                                }
                            }
                            else
                            {
                                retfinal = WRAPPER_CREATEFILE2(LogLevel_DebugBasic, cohorts.WsPackage, desiredAccess, shareMode, creationDisposition, createExParams, dllInstance);
                                return retfinal;
                            }
                        }
                        if (cohorts.NativeIsValidOptionInScenario &&
                            PathExists(cohorts.WsNative.c_str()))
                        {
                            if (IsAWriteCase)
                            {
                                if (Cow(LogLevel_DebugBasic, cohorts.WsNative, cohorts.WsRedirected, dllInstance, L"CreateFile2Fixup"))
                                {
                                    ///PreCreateFolders(testWsRedirected.c_str(), dllInstance, L"CreateFileFixup");
                                    retfinal = WRAPPER_CREATEFILE2(LogLevel_DebugBasic, cohorts.WsRedirected, desiredAccess, shareMode, creationDisposition, createExParams, dllInstance);
                                    return retfinal;
                                }
                                else
                                {
                                    retfinal = WRAPPER_CREATEFILE2(LogLevel_DebugBasic, cohorts.WsNative, desiredAccess, shareMode, creationDisposition, createExParams, dllInstance);
                                    return retfinal;
                                }
                            }
                            else
                            {
                                retfinal = WRAPPER_CREATEFILE2(LogLevel_DebugBasic, cohorts.WsNative, desiredAccess, shareMode, creationDisposition, createExParams, dllInstance);
                                return retfinal;
                            }
                        }
                        // There isn't such a file anywhere.  We want to create the redirection parent folder and let this call against the redirected file to create there.
                        PreCreateFolders(cohorts.WsRedirected.c_str(), dllInstance, L"CreateFile2Fixup");
                        retfinal = WRAPPER_CREATEFILE2(LogLevel_DebugBasic, cohorts.WsRedirected, desiredAccess, shareMode, creationDisposition, createExParams, dllInstance);
                        return retfinal;
                    }
                    break;
                case mfr::mfr_path_types::in_package_pvad_area:
                    if (cohorts.map.Valid_mapping == mfr::mfr_enabled_types::enabled)
                    {
                        if (PathExists(cohorts.WsPackage.c_str()))
                        {
                            if (MFRConfiguration.Ilv_Aware)
                            {
                                retfinal = WRAPPER_CREATEFILE2(LogLevel_DebugBasic, cohorts.WsPackage, desiredAccess, shareMode, creationDisposition, createExParams, dllInstance);
                                return retfinal;
                            }
                            else
                            {
                                //// try the redirected path, then package (COW), then don't need native.
                                if (cohorts.map.IsAnExclusionToRedirect == mfr::mfr_exclusion_types::not_excluded && 
                                    cohorts.WsRedirected.compare(cohorts.WsPackage) != 0 &&
                                    PathExists(cohorts.WsRedirected.c_str()))
                                {
                                    retfinal = WRAPPER_CREATEFILE2(LogLevel_DebugBasic, cohorts.WsRedirected, desiredAccess, shareMode, creationDisposition, createExParams, dllInstance);
                                    return retfinal;
                                }

                                if (IsAWriteCase)
                                {
                                    // COW is applicable first.
                                    if (Cow(LogLevel_DebugBasic, cohorts.WsPackage, cohorts.WsRedirected, dllInstance, L"CreateFile2Fixup"))
                                    {
                                        //PreCreateFolders(testWsRedirected.c_str(), dllInstance, L"CreateFileFixup");
                                        retfinal = WRAPPER_CREATEFILE2(LogLevel_DebugBasic, cohorts.WsRedirected, desiredAccess, shareMode, creationDisposition, createExParams, dllInstance);
                                        return retfinal;
                                    }
                                    else
                                    {
                                        retfinal = WRAPPER_CREATEFILE2(LogLevel_DebugBasic, cohorts.WsPackage, desiredAccess, shareMode, creationDisposition, createExParams, dllInstance);
                                        return retfinal;
                                    }
                                }
                                else
                                {
                                    retfinal = WRAPPER_CREATEFILE2(LogLevel_DebugBasic, cohorts.WsPackage, desiredAccess, shareMode, creationDisposition, createExParams, dllInstance);
                                    return retfinal;
                                }
                            }
                        }
                        // There isn't such a file anywhere.  We want to create the redirection parent folder and let this call against the redirected file to create there.
                        PreCreateFolders(cohorts.WsRedirected.c_str(), dllInstance, L"CreateFile2Fixup");
                        retfinal = WRAPPER_CREATEFILE2(LogLevel_DebugBasic, cohorts.WsRedirected, desiredAccess, shareMode, creationDisposition, createExParams, dllInstance);
                        return retfinal;
                    }
                    break;
                case mfr::mfr_path_types::in_package_vfs_area:
                    if (cohorts.map.RedirectionFlags == mfr::mfr_redirect_flags::prefer_redirection_local &&
                        cohorts.map.Valid_mapping == mfr::mfr_enabled_types::enabled)
                    {
                        // try the redirection path, then the package (COW).
                        if (cohorts.map.IsAnExclusionToRedirect == mfr::mfr_exclusion_types::not_excluded && 
                            PathExists(cohorts.WsRedirected.c_str()))
                        {
                            retfinal = WRAPPER_CREATEFILE2(LogLevel_DebugBasic, cohorts.WsRedirected, desiredAccess, shareMode, creationDisposition, createExParams, dllInstance);
                            return retfinal;
                        }
                        if (PathExists(cohorts.WsPackage.c_str()))
                        {
                            if (IsAWriteCase)
                            {
                                // COW is applicable first.
                                if (Cow(LogLevel_DebugBasic, cohorts.WsPackage, cohorts.WsRedirected, dllInstance, L"CreateFile2Fixup"))
                                {
                                    retfinal = WRAPPER_CREATEFILE2(LogLevel_DebugBasic, cohorts.WsRedirected, desiredAccess, shareMode, creationDisposition, createExParams, dllInstance);
                                    return retfinal;
                                }
                                else
                                {
                                    retfinal = WRAPPER_CREATEFILE2(LogLevel_DebugBasic, cohorts.WsPackage, desiredAccess, shareMode, creationDisposition, createExParams, dllInstance);
                                    return retfinal;
                                }
                            }
                            else
                            {
                                retfinal = WRAPPER_CREATEFILE2(LogLevel_DebugBasic, cohorts.WsPackage, desiredAccess, shareMode, creationDisposition, createExParams, dllInstance);
                                return retfinal;
                            }
                        }
                        // There isn't such a file anywhere.  We want to create the redirection parent folder and let this call against the redirected file to create there.
                        PreCreateFolders(cohorts.WsRedirected.c_str(), dllInstance, L"CreateFile2Fixup");
                        retfinal = WRAPPER_CREATEFILE2(LogLevel_DebugBasic, cohorts.WsRedirected, desiredAccess, shareMode, creationDisposition, createExParams, dllInstance);
                        return retfinal;
                    }
                    else if (cohorts.map.Valid_mapping == mfr::mfr_enabled_types::enabled &&
                        (cohorts.map.RedirectionFlags == mfr::mfr_redirect_flags::prefer_redirection_containerized ||
                            cohorts.map.RedirectionFlags == mfr::mfr_redirect_flags::prefer_redirection_if_package_vfs))
                    {
                        // try the redirection path, then the package (COW), then native (possibly COW)
                        if (PathExists(cohorts.WsPackage.c_str()))
                        {
                            if (MFRConfiguration.Ilv_Aware)
                            {
                                retfinal = WRAPPER_CREATEFILE2(LogLevel_DebugBasic, cohorts.WsPackage, desiredAccess, shareMode, creationDisposition, createExParams, dllInstance);
                                return retfinal;
                            }
                            else
                            {
                                if (cohorts.map.IsAnExclusionToRedirect == mfr::mfr_exclusion_types::not_excluded && 
                                    cohorts.WsRedirected.compare(cohorts.WsPackage) != 0 &&
                                    PathExists(cohorts.WsRedirected.c_str()))
                                {
                                    retfinal = WRAPPER_CREATEFILE2(LogLevel_DebugBasic, cohorts.WsRedirected, desiredAccess, shareMode, creationDisposition, createExParams, dllInstance);
                                    return retfinal;
                                }
                                if (IsAWriteCase)
                                {
                                    // COW is applicable first.
                                    if (Cow(LogLevel_DebugBasic, cohorts.WsPackage, cohorts.WsRedirected, dllInstance, L"CreateFile2Fixup"))
                                    {
                                        retfinal = WRAPPER_CREATEFILE2(LogLevel_DebugBasic, cohorts.WsRedirected, desiredAccess, shareMode, creationDisposition, createExParams, dllInstance);
                                        return retfinal;
                                    }
                                    else
                                    {
                                        retfinal = WRAPPER_CREATEFILE2(LogLevel_DebugBasic, cohorts.WsPackage, desiredAccess, shareMode, creationDisposition, createExParams, dllInstance);
                                        return retfinal;
                                    }
                                }
                                else
                                {
                                    retfinal = WRAPPER_CREATEFILE2(LogLevel_DebugBasic, cohorts.WsPackage, desiredAccess, shareMode, creationDisposition, createExParams, dllInstance);
                                    return retfinal;
                                }
                            }
                        }
                        if (cohorts.NativeIsValidOptionInScenario &&
                            PathExists(cohorts.WsNative.c_str()))
                        {
                            if (IsAWriteCase)
                            {
                                // COW is applicable first.
                                if (Cow(LogLevel_DebugBasic, cohorts.WsNative, cohorts.WsRedirected, dllInstance, L"CreateFile2Fixup"))
                                {
                                    retfinal = WRAPPER_CREATEFILE2(LogLevel_DebugBasic, cohorts.WsRedirected, desiredAccess, shareMode, creationDisposition, createExParams, dllInstance);
                                    return retfinal;
                                }
                                else
                                {
                                    retfinal = WRAPPER_CREATEFILE2(LogLevel_DebugBasic, cohorts.WsNative, desiredAccess, shareMode, creationDisposition, createExParams, dllInstance);
                                    return retfinal;
                                }
                            }
                            else
                            {
                                retfinal = WRAPPER_CREATEFILE2(LogLevel_DebugBasic, cohorts.WsNative, desiredAccess, shareMode, creationDisposition, createExParams, dllInstance);
                                return retfinal;
                            }
                        }
                        // There isn't such a file anywhere.  We want to create the redirection parent folder and let this call against the redirected file to create there.
                        PreCreateFolders(cohorts.WsRedirected.c_str(), dllInstance, L"CreateFile2Fixup");
                        retfinal = WRAPPER_CREATEFILE2(LogLevel_DebugBasic, cohorts.WsRedirected, desiredAccess, shareMode, creationDisposition, createExParams, dllInstance);
                        return retfinal;
                    }
                    break;
                case mfr::mfr_path_types::in_redirection_area_writablepackageroot:
                    if (cohorts.map.Valid_mapping == mfr::mfr_enabled_types::enabled)
                    {
                        // try the redirected path, then package (COW), then possibly native (Possibly COW).
                        if (cohorts.map.IsAnExclusionToRedirect == mfr::mfr_exclusion_types::not_excluded && 
                            PathExists(cohorts.WsRedirected.c_str()))
                        {
                            retfinal = WRAPPER_CREATEFILE2(LogLevel_DebugBasic, cohorts.WsRedirected, desiredAccess, shareMode, creationDisposition, createExParams, dllInstance);
                            return retfinal;
                        }
                        if (PathExists(cohorts.WsPackage.c_str()))
                        {
                            if (IsAWriteCase)
                            {
                                // COW is applicable first.
                                if (Cow(LogLevel_DebugBasic, cohorts.WsPackage, cohorts.WsRedirected, dllInstance, L"CreateFile2Fixup"))
                                {
                                    retfinal = WRAPPER_CREATEFILE2(LogLevel_DebugBasic, cohorts.WsRedirected, desiredAccess, shareMode, creationDisposition, createExParams, dllInstance);
                                    return retfinal;
                                }
                                else
                                {
                                    retfinal = WRAPPER_CREATEFILE2(LogLevel_DebugBasic, cohorts.WsPackage, desiredAccess, shareMode, creationDisposition, createExParams, dllInstance);
                                    return retfinal;
                                }
                            }
                            else
                            {
                                retfinal = WRAPPER_CREATEFILE2(LogLevel_DebugBasic, cohorts.WsPackage, desiredAccess, shareMode, creationDisposition, createExParams, dllInstance);
                                return retfinal;
                            }
                        }
                        if (cohorts.NativeIsValidOptionInScenario &&
                            PathExists(cohorts.WsNative.c_str()))
                        {
                            if (IsAWriteCase)
                            {
                                // COW is applicable first.
                                if (Cow(LogLevel_DebugBasic, cohorts.WsNative, cohorts.WsRedirected, dllInstance, L"CreateFile2Fixup"))
                                {
                                    retfinal = WRAPPER_CREATEFILE2(LogLevel_DebugBasic, cohorts.WsRedirected, desiredAccess, shareMode, creationDisposition, createExParams, dllInstance);
                                    return retfinal;
                                }
                                else
                                {
                                    retfinal = WRAPPER_CREATEFILE2(LogLevel_DebugBasic, cohorts.WsNative, desiredAccess, shareMode, creationDisposition, createExParams, dllInstance);
                                    return retfinal;
                                }
                            }
                            else
                            {
                                retfinal = WRAPPER_CREATEFILE2(LogLevel_DebugBasic, cohorts.WsNative, desiredAccess, shareMode, creationDisposition, createExParams, dllInstance);
                                return retfinal;
                            }
                        }
                        // There isn't such a file anywhere.  We want to create the redirection parent folder and let this call against the redirected file to create there.
                        PreCreateFolders(cohorts.WsRedirected.c_str(), dllInstance, L"CreateFile2Fixup");
                        retfinal = WRAPPER_CREATEFILE2(LogLevel_DebugBasic, cohorts.WsRedirected, desiredAccess, shareMode, creationDisposition, createExParams, dllInstance);
                        return retfinal;
                    }
                    break;
                case mfr::mfr_path_types::in_redirection_area_other:
                    break;
                case mfr::mfr_path_types::is_Protocol:
                case mfr::mfr_path_types::is_DosSpecial:
                case mfr::mfr_path_types::is_Shell:
                case mfr::mfr_path_types::in_other_drive_area:
                case mfr::mfr_path_types::is_UNC_path:
                case mfr::mfr_path_types::unsupported_for_intercepts:
                case mfr::mfr_path_types::unknown:
                default:
                    break;
                }
            }
            else
            {
                // ILV in use
                Log(LogLevel_DebugBasic, "[%s%d]\t\tScenario includes ILV", g_MfrModuleName, dllInstance);
                if (!IsThisUnsupportedForInterceptsNow(cohorts.WsRequested))
                {
                    std::wstring usePath = L"";

                    // 5/7/2025 change to make directories that are native use native
                    if (cohorts.file_mfr.Request_MfrPathType == mfr::mfr_path_types::in_native_area &&
                        IsPossibleDirectoryCase)
                    {
                        // Test if the native path exists and it is actually a directory, if so then use the native path (avoid for Draw.IO config issue)
                        DWORD att = ::GetFileAttributes(cohorts.WsNative.c_str());
                        if (att != INVALID_FILE_ATTRIBUTES &&
                            (att & FILE_ATTRIBUTE_DIRECTORY) != 0)
                        {
                            usePath = cohorts.WsRequested;
                            Log(LogLevel_DebugBasic, "[%s%d] Native Directory requested that exists, use that directory.", g_MfrModuleName, dllInstance);
                        }
                    }
                    if (usePath.length() == 0)
                    {
                        if (IsAWriteCase)
                        {
                            usePath = DetermineIlvPathForWriteOperations(LogLevel_DebugIntermediate, cohorts, dllInstance);
                            // In a redirect to local scenario, we are responsible for pre-creating the local parent folders
                            // if-and-only-if they are present in the package.
                            PreCreateLocalFoldersIfNeededForWrite(LogLevel_DebugBasic, usePath, cohorts.WsPackage, dllInstance, L"CreateFile2Fixup");
                            // In a redirect to local scenario, if the file is not present locally, but is in the package, we are responsible to copy it there first.
                            CowLocalFoldersIfNeededForWrite(LogLevel_DebugBasic, usePath, cohorts.WsPackage, dllInstance, L"CreateFile2Fixup");
                            // In a write to package scenario, folders may be needed.
                            PreCreatePackageFoldersIfIlvNeededForWrite(LogLevel_DebugBasic, usePath, dllInstance, L"CreateFile2Fixup");
                        }
                        else
                        {
                            usePath = DetermineIlvPathForReadOperations(LogLevel_DebugIntermediate, cohorts, dllInstance);
                            // In a redirect to local scenario, we are responsible for determining if source is local or in package
                            usePath = SelectLocalOrPackageForRead(usePath, cohorts.WsPackage);
                        }
                    }

                    retfinal = WRAPPER_CREATEFILE2(LogLevel_DebugBasic, usePath, desiredAccess, shareMode, creationDisposition, createExParams, dllInstance);

                    // Special case to keep app from getting confused by giving them VFS\AppVPackageRoot instead of C:\.
                    // We still want to precreate that folder in case they are going to add to it.
                    if (retfinal != INVALID_HANDLE_VALUE &&
                        fileName != nullptr)
                    {
                        std::wstring wpath = fileName;
                        if (wStringToLower(wpath) ==  L"\\?\\c:" ||
                            wStringToLower(wpath) == L"\\?\\c:\\" ||
                            wStringToLower(wpath) == L"c:" ||
                            wStringToLower(wpath) == L"c:\\" )
                        {
                            CloseHandle(retfinal);
                            retfinal = WRAPPER_CREATEFILE2(LogLevel_DebugBasic, fileName, desiredAccess, shareMode, creationDisposition, createExParams, dllInstance);
                        }
                    }
                    return retfinal;
                }
                // else fall through
            }
        }
    }
    // Fall back to assuming no redirection is necessary if exception
    LOGGED_CATCHHANDLER_MIN(LogLevel_DebugBasic, g_MfrModuleName, dllInstance, L"CreateFile2Fixup")

    if (fileName != nullptr)
    {
        // As in CreateFileFixup, we are not doing long path conversion here for now.
        //std::wstring LongDirectory = MakeLongPath(fileName);
        //retfinal = impl::CreateFile2(LongDirectory.c_str(), desiredAccess, shareMode, creationDisposition, createExParams);
        retfinal = impl::CreateFile2(fileName, desiredAccess, shareMode, creationDisposition, createExParams);
    }
    else
    {
        SetLastError(ERROR_INVALID_PARAMETER);
        retfinal = INVALID_HANDLE_VALUE; //impl::CreateFile2(fileName, desiredAccess, shareMode, creationDisposition, createExParams);
    }
    Log(LogLevel_DebugBasic, L"[%s%d] CreateFile2Fixup returns handle 0x%x", g_MfrModuleName, dllInstance, retfinal);
    return retfinal;
}
DECLARE_FIXUP(impl::CreateFile2, CreateFile2Fixup);
