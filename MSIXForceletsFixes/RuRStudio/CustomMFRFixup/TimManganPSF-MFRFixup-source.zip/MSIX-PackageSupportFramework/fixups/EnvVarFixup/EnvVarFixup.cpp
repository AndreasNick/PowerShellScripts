//-------------------------------------------------------------------------------------------------------
// Copyright (C) Tim Mangan. All rights reserved
// Copyright (C) Microsoft Corporation. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.
//-------------------------------------------------------------------------------------------------------

#include <regex>
#include <psf_framework.h>
#include <psf_logging.h>
#include "FunctionImplementations.h"
#include "EnvVar_spec.h"

#if _DEBUG
//#define MOREDEBUG 1
#endif

extern std::vector<env_var_spec> g_envvar_envVarSpecs;

DWORD g_EnvVarInterceptInstance = 40000;
const wchar_t* g_EnvVarName = L"E";



//ExpandEnvironmentStrings
//  [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Auto)]
//  public static extern int ExpandEnvironmentStrings([MarshalAs(UnmanagedType.LPTStr)] String source, [Out] StringBuilder destination, int size);


//GetEnvironmentVariable
//      DllImport("kernel32.dll")]
//  static extern uint GetEnvironmentVariable(string lpName,
//      [Out] StringBuilder lpBuffer, uint nSize);
//

// INTERESTING NOTE:
// Although lpName is shown as an optional input in the Microsoft documentation, it is not actually supported to be NULL.
// It isn't clear why this is an allowed call, and it seems to just return 0 and set no error.
auto GetEnvironmentVariableImpl = psf::detoured_string_function(&::GetEnvironmentVariableA, &::GetEnvironmentVariableW);
template <typename CharC, typename CharT>
DWORD __stdcall GetEnvironmentVariableFixup(_In_ const CharC* lpName, _Inout_ CharT* lpValue, _In_ DWORD lenBuf)
{
    DWORD GetEnvVarInstance = ++g_EnvVarInterceptInstance;
    auto guard = g_reentrancyGuard.enter();
    DWORD result;

    if (guard)
    {
        if (lpName != NULL)
        {
            LogString(LogLevel_DebugBasic, g_EnvVarName, GetEnvVarInstance, L"GetEnvironmentVariableFixup called for", lpName);
        }
        else
        {
            Log(LogLevel_DebugBasic, L"[%s%d] GetEnvironmentVariableFixup called with Name=NULL returning 0", g_EnvVarName, GetEnvVarInstance);
            return 0;
        }

        std::wstring eName;
        if constexpr (psf::is_ansi<CharT>)
        {
            eName = widen(lpName);
        }
        else
        {
            eName =lpName;
        }

        for (env_var_spec spec : g_envvar_envVarSpecs)
        {
            try
            {
                if (std::regex_match(eName, spec.variablename))
                {
                    size_t valuelen = spec.variablevalue.length();
                    if (spec.useregistry == true)
                    {
                        Log(LogLevel_DebugIntermediate, L"[%s%d] GetEnvironmentVariableFixup: Registry supplied case.", g_EnvVarName, GetEnvVarInstance);
                        // Check app registry for an answer instead of the Json. Note: this allows value to be modified possibly also.
                        HKEY hKeyCU;
                        if constexpr (psf::is_ansi<CharT>)
                        {
                            if (RegOpenKeyExA(HKEY_CURRENT_USER, "Environment",
                                0, KEY_ENUMERATE_SUB_KEYS | KEY_READ | KEY_QUERY_VALUE, &hKeyCU) == ERROR_SUCCESS)
                            {
                                Log(LogLevel_DebugIntermediate, L"[%s%d] GetEnvironmentVariableFixup:(A) HKCU key found.", g_EnvVarName, GetEnvVarInstance);
                                DWORD type = RRF_RT_REG_SZ;
                                DWORD dLen = (DWORD)lenBuf;
                                auto ret = RegGetValueA(HKEY_CURRENT_USER, "Environment", lpName,
                                    RRF_RT_REG_SZ | RRF_RT_REG_EXPAND_SZ | RRF_ZEROONFAILURE, &type, lpValue, &dLen);
                                if (ret == ERROR_SUCCESS)
                                {
                                    if (lpValue != NULL)
                                    {
                                        Log(LogLevel_DebugBasic, L"[%s%d] GetEnvironmentVariableFixup:(A) HKCU value found %s", g_EnvVarName, GetEnvVarInstance, lpValue);
                                    }
                                    else
                                    {
                                        Log(LogLevel_DebugBasic, L"[%s%d] GetEnvironmentVariableFixup:(A) HKCU value found but the actual value not requested by caller", g_EnvVarName, GetEnvVarInstance);
                                    }
                                    result = dLen;
                                    RegCloseKey(hKeyCU);
                                    return result;
                                }
                                else
                                {
                                    Log(LogLevel_DebugBasic, L"[%s%d] GetEnvironmentVariableFixup:(A) HKCU value Failed 0x%x.", g_EnvVarName, GetEnvVarInstance, ret);
                                }
                                RegCloseKey(hKeyCU);
                            }
                        }
                        else
                        {
                            if (RegOpenKeyExW(HKEY_CURRENT_USER, L"Environment",
                                0, KEY_ENUMERATE_SUB_KEYS | KEY_READ | KEY_QUERY_VALUE, &hKeyCU) == ERROR_SUCCESS)
                            {
                                Log(LogLevel_DebugIntermediate, L"[%s%d] GetEnvironmentVariableFixup:(W) HKCU key found.", g_EnvVarName, GetEnvVarInstance);
                                LogString(LogLevel_DebugIntermediate, g_EnvVarName, GetEnvVarInstance, L"GetEnvironmentVariableFixup:(W) Looking for ", lpName);

                                DWORD type = RRF_RT_REG_SZ;
                                DWORD dLen = lenBuf;
                                auto ret = RegGetValueW(HKEY_CURRENT_USER, L"Environment", lpName,
                                    RRF_RT_REG_SZ | RRF_RT_REG_EXPAND_SZ | RRF_ZEROONFAILURE, &type, lpValue, &dLen);
                                if (ret == ERROR_SUCCESS)
                                {
                                    if (lpValue != NULL)
                                    {
                                        Log(LogLevel_DebugBasic, "[%s%d] GetEnvironmentVariableFixup:(W) HKCU value found %ls", g_EnvVarName, GetEnvVarInstance, lpValue);
                                    }
                                    else
                                    {
                                        Log(LogLevel_DebugBasic, "[%s%d] GetEnvironmentVariableFixup:(W) HKCU value found but the actual value not requested by caller", g_EnvVarName, GetEnvVarInstance);
                                    }
                                    result = dLen;
                                    RegCloseKey(hKeyCU);
                                    return result;
                                }
                                else
                                {
                                    Log(LogLevel_DebugBasic, L"[%s%d] GetEnvironmentVariableFixup:(W) HKCU value Failed 0x%x.", g_EnvVarName, GetEnvVarInstance, ret);
                                }
                                RegCloseKey(hKeyCU);
                            }
                        }
                        result = 0;

                        HKEY hKeyLM;
                        if constexpr (psf::is_ansi<CharT>)
                        {
                            if (RegOpenKeyExA(HKEY_LOCAL_MACHINE, "SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Environment",
                                0, KEY_ENUMERATE_SUB_KEYS | KEY_READ | KEY_QUERY_VALUE, &hKeyLM) == ERROR_SUCCESS)
                            {
                                Log(LogLevel_DebugIntermediate, L"[%s%d] GetEnvironmentVariableFixup:(A) HKLM key found.", g_EnvVarName, GetEnvVarInstance);
                                LONG dLen0 = (LONG)lenBuf;
                                auto ret00 = RegQueryValueA(hKeyLM, lpName, lpValue, &dLen0);
                                if (ret00 == ERROR_SUCCESS)
                                {
                                    if (lpValue != NULL)
                                    {
                                        Log(LogLevel_DebugBasic, L"[%s%d] GetEnvironmentVariableFixup:(A) HKLM value queried! %s", g_EnvVarName, GetEnvVarInstance, lpValue);
                                    }
                                    else
                                    {
                                        Log(LogLevel_DebugBasic, L"[%s%d] GetEnvironmentVariableFixup:(A) HKLM value queried! But the actual value not requested by caller", g_EnvVarName, GetEnvVarInstance);
                                    }
                                    result = (DWORD)dLen0;
                                    RegCloseKey(hKeyLM);
                                    return result;
                                }
                                else
                                {
                                    Log(LogLevel_DebugBasic, L"[%s%d] GetEnvironmentVariableFixup:(W) HKCU value Failed 0x%x.", g_EnvVarName, GetEnvVarInstance, ret00);
                                }

                                RegCloseKey(hKeyLM);
                            }
                        }
                        else
                        {
                            if (RegOpenKeyExW(HKEY_LOCAL_MACHINE, L"SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Environment",
                                0, KEY_ENUMERATE_SUB_KEYS | STANDARD_RIGHTS_READ | KEY_QUERY_VALUE, &hKeyLM) == ERROR_SUCCESS)
                            {
                                Log(LogLevel_DebugIntermediate, L"[%s%d] GetEnvironmentVariableFixup:(W) HKLM key found.", g_EnvVarName, GetEnvVarInstance);
                                DWORD type = RRF_RT_REG_SZ;
                                DWORD dLen = lenBuf;
                                auto ret = RegGetValueW(HKEY_LOCAL_MACHINE, L"SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Environment", lpName,
                                    RRF_RT_REG_SZ | RRF_RT_REG_EXPAND_SZ | RRF_ZEROONFAILURE, &type, lpValue, &dLen);
                                if (ret == ERROR_SUCCESS)
                                {
                                    if (lpValue != NULL)
                                    {
                                        Log(LogLevel_DebugBasic, "[%s%d] GetEnvironmentVariableFixup:(W) HKLM value found %ls", g_EnvVarName, GetEnvVarInstance, lpValue);
                                    }
                                    else
                                    {
                                        Log(LogLevel_DebugBasic, "[%s%d] GetEnvironmentVariableFixup:(W) HKLM value found but the actual value not requested by caller", g_EnvVarName, GetEnvVarInstance);
                                    }
                                    result = dLen;
                                    RegCloseKey(hKeyLM);
                                    return result;
                                }
                                else
                                {
                                    Log(LogLevel_DebugBasic, L"[%s%d] GetEnvironmentVariableFixup:(W) HKLM value Failed 0x%x.", g_EnvVarName, GetEnvVarInstance, ret);
                                }
                                RegCloseKey(hKeyLM);
                            }
                        }
                        // allow to fall through to system
                        //return result;
                        result = 0;
                    }

                    // Sometimes HKLM\System reg items from the package are not visible to the app.  We think this is a bug, so
                    // allow a check to see if there is a value field in the JSON and use that.
                    // Of course, we should always look at the json if useregistry was set to false anyway.

                    Log(LogLevel_DebugIntermediate, L"[%s%d] GetEnvironmentVariableFixup: Json supplied case.", g_EnvVarName, GetEnvVarInstance);

                    if (valuelen <= lenBuf)
                    {
                        Log(LogLevel_DebugIntermediate, L"[%s%d] GetEnvironmentVariableFixup: Match to be returned.", g_EnvVarName, GetEnvVarInstance);
                        // copy into lpValue, but might need form conversion
                        if constexpr (psf::is_ansi<CharT>)
                        {

                            std::string sval = narrow(spec.variablevalue);

                            // TOCONSIDER: If the value has a {[RegistryVar}] in it, we should replace with relative VFS\Var or native equivalent

                            LogString(LogLevel_DebugIntermediate, g_EnvVarName, GetEnvVarInstance, L"GetEnvironmentVariableFixup:(A) HKCU value is ", sval.c_str());
                            if (lpValue != NULL)
                            {
                                ZeroMemory(lpValue, lenBuf);
                                sval.copy(lpValue, lenBuf, 0);
                                //strcpy_s(lpValue, lenBuf, sval.c_str());
                                LogString(LogLevel_DebugBasic, g_EnvVarName, GetEnvVarInstance, L"GetEnvironmentVariableFixup:(A) HKCU value copied is ", lpValue);
                            }
                            else
                            {
                                LogString(LogLevel_DebugBasic, g_EnvVarName, GetEnvVarInstance, L"GetEnvironmentVariableFixup:(A) HKCU value not actually requested by caller ", sval.c_str());
                            }
                            result = (DWORD)sval.length();
                        }
                        else
                        {
                            LogString(LogLevel_DebugIntermediate, g_EnvVarName, GetEnvVarInstance, L"GetEnvironmentVariableFixup:(W) HKCU value is ", spec.variablevalue.data());

                            // TOCONSIDER: If the value has a {[RegistryVar}] in it, we should replace with relative VFS\Var or native equivalent
                            if (lpValue != NULL)
                            {
                                ZeroMemory(lpValue, lenBuf);
                                spec.variablevalue.copy(lpValue, lenBuf, 0);
                                LogString(LogLevel_DebugBasic, g_EnvVarName, GetEnvVarInstance, L"GetEnvironmentVariableFixup:(W) HKCU value copied is ", lpValue);
                            }
                            else
                            {
                                LogString(LogLevel_DebugBasic, g_EnvVarName, GetEnvVarInstance, L"GetEnvironmentVariableFixup:(W) HKCU value not requested by caller ", L"");
                            }
                            result = (DWORD)valuelen;
                        }
                        Log(LogLevel_DebugIntermediate, L"[%s%d] GetEnvironmentVariableFixup: Value saved.", g_EnvVarName, GetEnvVarInstance);
                        SetLastError(ERROR_SUCCESS);
                        return(result);
                    }
                    else
                    {
                        if constexpr (psf::is_ansi<CharT>)
                        {
                            Log(LogLevel_DebugBasic, L"[%s%d] GetEnvironmentVariableFixup: (A) Match returns bufferoverflow. Needs 0x%x more than 0x%x.", g_EnvVarName, GetEnvVarInstance,valuelen-lenBuf, lenBuf);
                        }
                        else
                        {
                            Log(LogLevel_DebugBasic, L"[%s%d] GetEnvironmentVariableFixup: (W) Match returns bufferoverflow. Needs 0x%x more than 0x%x.", g_EnvVarName, GetEnvVarInstance, valuelen - lenBuf, lenBuf);
                        }
                        // return buffer overflow
                        result = ERROR_BUFFER_OVERFLOW;
                        SetLastError(ERROR_BUFFER_OVERFLOW);
                        return(result);
                    }

                }
            }
            catch (...)
            {
                Log(LogLevel_Exception, L"[%s%d] Bad Regex pattern ignored in EnvVarFixup.\n", g_EnvVarName, GetEnvVarInstance);
            }
        }

        // If still here, make original call

        Log(LogLevel_DebugIntermediate, L"[%s%d] GetEnvironmentVariableFixup: No match - fall through.", g_EnvVarName, GetEnvVarInstance);
    }
    result = GetEnvironmentVariableImpl(lpName, lpValue, lenBuf);
    if (result == 0)
    {
        DWORD error = GetLastError();
        if (error == ERROR_ENVVAR_NOT_FOUND)
        {
            Log(LogLevel_DebugBasic, L"[%s%d] GetEnvironmentVariableFixup: Original call returned ERROR_ENVVAR_NOT_FOUND.", g_EnvVarName, GetEnvVarInstance);
        }
        else
        {
            Log(LogLevel_DebugBasic, L"[%s%d] GetEnvironmentVariableFixup: Original call failed with 0x%x.", g_EnvVarName, GetEnvVarInstance, error);
        }
    }
    else
    {
        try
        {
            if (lpValue != NULL)
            {
                if constexpr (psf::is_ansi<CharT>)
                {
                    Log(LogLevel_DebugBasic, L"[%s%d] GetEnvironmentVariableFixup fall-though returns %d with value %s", g_EnvVarName, GetEnvVarInstance, result, widen(lpValue).c_str());
                }
                else
                {
                    Log(LogLevel_DebugBasic, L"[%s%d] GetEnvironmentVariableFixup fall-through returns %d with value %s", g_EnvVarName, GetEnvVarInstance, result, lpValue);
                }
            }
            else
            {
                Log(LogLevel_DebugBasic, L"[%s%d] GetEnvironmentVariableFixup fall-through returns %d but the actual value not requested by caller", g_EnvVarName, GetEnvVarInstance, result);
            }
        }
        catch (...)
        {
            Log(LogLevel_Exception, L"[%s%d] GetEnvironmentVariableFixup fall-through returns %d with value <unprintable>", g_EnvVarName, GetEnvVarInstance, result);
        }
    }
    return result;
}
DECLARE_STRING_FIXUP(GetEnvironmentVariableImpl, GetEnvironmentVariableFixup);


//SetEnvironmentVariable
//  [DllImport("kernel32.dll", SetLastError=true)]
//  static extern bool SetEnvironmentVariable(string lpName, string lpValue);
auto SetEnvironmentVariableImpl = psf::detoured_string_function(&::SetEnvironmentVariableA, &::SetEnvironmentVariableW);
template <typename CharT>
BOOL __stdcall SetEnvironmentVariableFixup(_In_ const CharT* lpName, _In_ const CharT* lpValue)
{
    DWORD SetEnvVarInstance = ++g_EnvVarInterceptInstance;
    LogString(LogLevel_DebugBasic, g_EnvVarName, SetEnvVarInstance, L"SetEnvironmentVariableFixup called for", lpName);

    auto guard = g_reentrancyGuard.enter();
    BOOL result;

    if (guard)
    {
        std::wstring eName;
        if constexpr (psf::is_ansi<CharT>)
        {
            eName = widen(lpName);
        }
        else
        {
            eName = lpName;
        }
        Log(LogLevel_DebugBasic, L"[%s%d] SetEnvironmentVariableFixup for %s.", g_EnvVarName, SetEnvVarInstance, eName.c_str());

        for (env_var_spec spec : g_envvar_envVarSpecs)
        {
            try
            {
                if (std::regex_match(eName, spec.variablename))
                {
                    if (spec.useregistry == true)
                    {
                        Log(LogLevel_DebugIntermediate, L"[%s%d] SetEnvironmentVariableFixup: registry case.", g_EnvVarName, SetEnvVarInstance);
                        HKEY hKeyCU;
                        if constexpr (psf::is_ansi<CharT>)
                        {
                            if (RegOpenKeyExA(HKEY_CURRENT_USER, "Environment", 0, MAXIMUM_ALLOWED, &hKeyCU) == ERROR_SUCCESS)
                            {
                                DWORD dLen;
                                if (lpValue != NULL)
                                {
                                    dLen = (DWORD)((strlen(lpValue) + 1) * sizeof(CharT));
                                }
                                else
                                {
                                    dLen = 0;
                                }
                                auto ret = RegSetValueExA(hKeyCU, lpName, NULL, REG_SZ, (BYTE*)lpValue, dLen);
                                if (ret == ERROR_SUCCESS)
                                {
                                    if (lpValue != NULL)
                                    {
                                        Log(LogLevel_DebugBasic, L"[%s%d] SetEnvironmentVariableFixup: success. %s=%s", g_EnvVarName, SetEnvVarInstance, lpName, lpValue);
                                    }
                                    else
                                    {
                                        Log(LogLevel_DebugBasic, L"[%s%d] SetEnvironmentVariableFixup: success. %s=NULL", g_EnvVarName, SetEnvVarInstance, lpName);
                                    }
                                    result = 1;
                                    return result;
                                }
                                else
                                {
                                    Log(LogLevel_DebugBasic, L"[%s%d] SetEnvironmentVariableFixup: Failure 0x%x.", g_EnvVarName, SetEnvVarInstance, GetLastError());
                                    result = 0;
                                    return result;
                                }
                            }
                        }
                        else
                        {
                            if (RegOpenKeyExW(HKEY_CURRENT_USER, L"Environment", 0, MAXIMUM_ALLOWED, &hKeyCU) == ERROR_SUCCESS)
                            {
                                DWORD dLen;
                                if (lpValue != NULL)
                                {
                                    dLen = (DWORD)((wcslen(lpValue) + 1) * sizeof(CharT));
                                }
                                else
                                {
                                    dLen = 0;
                                }
                                auto ret = RegSetValueExW(hKeyCU, lpName, NULL, REG_SZ, (BYTE*)lpValue, dLen);
                                if (ret == ERROR_SUCCESS)
                                {
                                    if (lpValue != NULL)
                                    {
                                        Log(LogLevel_DebugBasic, L"[%s%d] SetEnvironmentVariableFixup: success. %ls=%ls", g_EnvVarName, SetEnvVarInstance, lpName, lpValue);
                                    }
                                    else
                                    {
                                        Log(LogLevel_DebugBasic, L"[%s%d] SetEnvironmentVariableFixup: success. %ls=NULL", g_EnvVarName, SetEnvVarInstance, lpName);
                                    }
                                    result = 1;
                                    return result;
                                }
                                else
                                {
                                    Log(LogLevel_DebugBasic, L"[%s%d] SetEnvironmentVariableFixup: Failure 0x%x.", g_EnvVarName, SetEnvVarInstance, GetLastError());
                                    result = 0;
                                    return result;
                                }
                            }
                        }
                    }
                    else
                    {
                        Log(LogLevel_DebugBasic, L"[%s%d] SetEnvironmentVariableFixup: JSON case - returning ACCESS_DENIED.", g_EnvVarName, SetEnvVarInstance);
                        // Unable to overwrite json, return ACCESS_DENIED
                        SetLastError(ERROR_ACCESS_DENIED);
                        result = 0;
                        return result;
                    }
                }
            }
            catch (...)
            {
                Log(LogLevel_Exception, L"[%s%d] Bad Regex pattern ignored in EnvVarFixup.\n", g_EnvVarName, SetEnvVarInstance);
            }
        }
    }

    // If still here, make original call

    result = SetEnvironmentVariableImpl(lpName, lpValue);
    return result;
}
DECLARE_STRING_FIXUP(SetEnvironmentVariableImpl, SetEnvironmentVariableFixup);
